
create table if not exists building_costs (
	occupancy char(30),    
	structures char(15),
    costs int,
    primary key ("occupancy", "structures")
);

create table if not exists building_csvr (
    occupancy char(30),
    csvr real,
    primary key ("occupancy")
);

create table if not exists building_entrance (
    occupancy char(30),
    height real,
    primary key ("occupancy")
);

create table if not exists building_depreciation (
	occupancy char(30),    
	structures char(15),
    persisting_period real,
    primary key ("occupancy", "structures")
);

--create table if not exists building_structure_damage_rate (
--	occupancy char(30), 
--	structures char(15),
--	"0" real,	"1" real,    "2" real,    "3" real,    "4" real,
--    "5" real,    "6" real,    "7" real,    "8" real,
--    "9" real,    "10" real,    "11" real,
----	"0-0.3m" real,	"0.3-0.6m" real,	"0.6-0.9m" real,	"0.9-1.2m" real,	
----	"1.2-1.5m" real,	"1.5-1.8m" real,	"1.8-2.1m" real,	"2.1-2.4m" real,	
----	"2.4-2.7m" real,	"2.7-3.0m" real,	"3.0m-" real,
--	primary key ("occupancy", "structures")
--);
--
--create table if not exists building_inner_damage_rate (
--	occupancy char(30), 
--	"0" real,	"1" real,    "2" real,    "3" real,    "4" real,
--    "5" real,    "6" real,    "7" real,    "8" real,
--    "9" real,    "10" real,    "11" real,
----	"0-0.3m" real,	"0.3-0.6m" real,	"0.6-0.9m" real,	"0.9-1.2m" real,	
----	"1.2-1.5m" real,	"1.5-1.8m" real,	"1.8-2.1m" real,	"2.1-2.4m" real,	
----	"2.4-2.7m" real,	"2.7-3.0m" real,	"3.0m-" real,
--	primary key ("occupancy")
--);
--
--create table if not exists vehicle_dmg_func (
--	"type" text, 
--	"0" real,	"1" real,    "2" real,    "3" real,    "4" real,
--    "5" real,    "6" real,    "7" real,    "8" real,
--    "9" real,    "10" real,    "11" real,
--    primary key ("type")
--);
--
--create table if not exists population_life_loss (
--	hierarchy text,
--	"0" real,	"1" real,    "2" real,    "3" real,    "4" real,
--    "5" real,    "6" real,    "7" real,    "8" real,
--    "9" real,    "10" real,    "11" real,
--	primary key ("hierarchy")
--);
--
--create table if not exists population_victim_loss (
--	hierarchy text,
--	"0" real,	"1" real,    "2" real,    "3" real,    "4" real,
--    "5" real,    "6" real,    "7" real,    "8" real,
--    "9" real,    "10" real,    "11" real,
--	primary key ("hierarchy")
--);

create table if not exists population_unit_cost (
	year int,
	life_loss int,
	victim_loss int,
	primary key ("year")
);

create table if not exists agriculture_stdr_price_flow (
	farmland char(5) NOT NULL,
	crops char(9) not null,
	may real,
	jun real, 
	jul real,
	aug real
);

create table if not exists agriculture_price_flow (
	farmland char(5) NOT NULL,
	crops char(9) not null,
	stndr_prd_cst real,
	stndr_income real,
	input_prd_cst real, 
	expct_netpr real
);

--create table if not exists agriculture_crop_dmg_func (
--	farmland character(5) NOT NULL,
--	crops character(9) NOT null,
--	"0" real,	"1" real,    "2" real,    "3" real,    "4" real,
--    "5" real,    "6" real,    "7" real,    "8" real,
--    "9" real,    "10" real,    "11" real,
--	primary key (farmland, crops)
--);
--
--create table if not exists agriculture_frm_dmg_func (
--	farmland character(5) NOT NULL,
--	"0" real,	"1" real,    "2" real,    "3" real,    "4" real,
--    "5" real,    "6" real,    "7" real,    "8" real,
--    "9" real,    "10" real,    "11" real,
--	primary key (farmland)
--);

create table if not exists agriculture_unit_cost (
	unit real
);

create table if not exists flood_table_list (
	path text, --파일 경로
	frequency int, --홍수 빈도
	comment text,
	table_name text, --테이블 명
	flood_column text, --침수 필드 명
	area text, --침수 구역도 해당 지역
	area_count text --침수 구역도 순서?
);

create table if not exists flood_sum_result(
	type text, 
	building real, 
	vehicle real, 
	life real, 
	victim real, 
	crop real, 
	farmland real, 
	sum real
);

create table if not exists reclass_field_table(
	ogc_fid int not null,
	code text not null,
	min real not null, 
	max real not null,
	primary key (ogc_fid, code)
);