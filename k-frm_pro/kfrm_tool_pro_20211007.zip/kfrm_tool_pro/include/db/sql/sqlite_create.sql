
create table if not exists building_costs (
	occupancy char(30),    
	description char(15),
    costs int,
    primary key ("occupancy", "description")
);

create table if not exists building_csvr (
    occupancy char(30),
    csvr real,
    primary key ("occupancy")
);

create table if not exists building_entrance (
    occupancy char(30),
    height real,
    primary key ("occupancy")
);

create table if not exists building_depreciation (
	occupancy char(30),    
	description char(15),
    persisting_period real,
    primary key ("occupancy", "description")
);

create table if not exists population_unit_cost (
	year int,
	life_loss int,
	victim_loss int,
	primary key ("year")
);

create table if not exists agriculture_stdr_price_flow (
	farmland char(5) NOT NULL,
	crops char(9) not null,
	may real,
	jun real, 
	jul real,
	aug real
);

create table if not exists agriculture_price_flow (
	farmland char(5) NOT NULL,
	crops char(9) not null,
	stndr_prd_cst real,
	stndr_income real,
	input_prd_cst real, 
	expct_netpr real
);

create table if not exists agriculture_unit_cost (
	unit real
);

create table if not exists flood_table_list (
	path text, --파일 경로
	frequency int, --홍수 빈도
	comment text,
	table_name text, --테이블 명
	flood_column text, --침수 필드 명
	area text, --침수 구역도 해당 지역
	area_count text --침수 구역도 순서?
);

create table if not exists flood_sum_result(
	type text, 
	building real, 
	vehicle real, 
	life real, 
	victim real, 
	crop real, 
	farmland real, 
	sum real
);

create table if not exists reclass_field_table(
	ogc_fid int not null,
	code text not null,
	min real not null, 
	max real not null,
	primary key (ogc_fid, code)
);

-- 아래는 서버에서 가져온 정보를 저장하는 테이블들 ----------------------------------------

--create table if not exists building_costs_ori (
--	order_id integer not null, 
--	occupancy char(30),    
--	structures char(15),
--    costs int,
--    primary key ("occupancy", "structures")
--);
--
--create table if not exists building_csvr_ori (
--	order_id integer not null, 
--    occupancy char(30),
--    csvr real,
--    primary key ("occupancy")
--);
--
--create table if not exists building_entrance_ori (
--	order_id integer not null, 
--    occupancy char(30),
--    height real,
--    primary key ("occupancy")
--);
--
--create table if not exists building_depreciation_ori (
--	order_id integer not null, 
--	occupancy char(30),    
--	structures char(15),
--    persisting_period real,
--    primary key ("occupancy", "structures")
--);
--
--create table if not exists population_unit_cost_ori (
--	order_id integer not null, 
--	year int,
--	life_loss int,
--	victim_loss int,
--	primary key ("year")
--);
--
--create table if not exists agriculture_stdr_price_flow_ori (
--	order_id integer not null, 
--	farmland char(5) NOT NULL,
--	crops char(9) not null,
--	may real,
--	jun real, 
--	jul real,
--	aug real
--);
--
--create table if not exists agriculture_price_flow_ori (
--	order_id integer not null, 
--	farmland char(5) NOT NULL,
--	crops char(9) not null,
--	stndr_prd_cst real,
--	stndr_income real,
--	input_prd_cst real, 
--	expct_netpr real
--);
