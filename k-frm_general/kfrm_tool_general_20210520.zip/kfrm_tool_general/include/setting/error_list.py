# -*- coding: utf-8 -*-
from ..File_Class import ChFile_Exists

class ErrorConfirm:
    #파일을 선택하는 곳에서 경로가 비어있거나, 존재하지 않는 경로일 경우 에러.
    def filePathErrorConfirm(self, filePath, msg=""):
        if filePath.strip() == "" :
            msg = msg if msg else "No path was specified."
            raise Warning(msg)
        
        if not ChFile_Exists(filePath):
            msg = msg if msg else "The path specified is not valid."
            raise Warning(msg)
    
    def notTableSelectetConfirm(self, tbl):
        msg = "All information required for the calculation has not been entered."
        rowCount, colCount = self.tableEmptyConfirm(tbl, msg)
           
        for r in range(rowCount):
            for c in range(colCount):
                item = tbl.item(r, c)
                if not item or not item.text():
                    raise Warning(msg)
    
    def notTableOneWidgetConfirm(self, tbl, colIndex, msg=""):
        msg = "Command has not been entered."
        rowCount = tbl.rowCount()
        for r in range(rowCount):
            items = tbl.cellWidget(r, colIndex)
            if not items or not items.text():
                raise Warning(msg)
    
    def listOverlapConfirm(self, target, msg=""):
        msg = "Cannot use duplicate names. \nPlease change the flood frequency value or command value."
        origin = len(target)
        confirm = len(list(set(target)))
        if origin!=confirm:
            raise  Warning(msg)
                
    def canvasEmptyConfirm(self, canvas):
        if not canvas.layers():
            raise Warning("The hazard map is not loaded.")
        
    def notSelectComboIndex(self, cmb, msg, cnt=0):
        if cmb.currentIndex()<=cnt:
            raise Warning(f"{msg} is not selected.")
    
    def noneSelectedType(self, typeList, msg="No save data format was specified."):
        if True not in typeList:
            raise Warning(msg)
        
    def tableEmptyConfirm(self, tbl, msg="The file is not exist.", toggle=True):
        rowCount = tbl.rowCount()
        colCount = tbl.columnCount()
        
        if toggle and (not rowCount or not colCount):
            raise Warning(msg)
    
        return rowCount, colCount
    
    def lossNoneDataTables(self, contentList):
        if not contentList:
            raise Warning("Flood data is not loaded.")
        elif not contentList[0][1]:
            raise Warning("The add map process was not performed.")
        
    def noneResultListData(self, conList, msg=""):
        msg = msg if msg else "The result data to be exported does not exist."
        if not conList:
            raise Warning(msg)
    
    def iconCheck(self, widget, msg=""):
        if widget.icon(0).isNull():
            raise Warning(msg)