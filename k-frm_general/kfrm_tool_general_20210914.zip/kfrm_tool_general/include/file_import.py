from .setting.path_list import DefaultPath
from .Util import callExecute

class FileImport:
    def __init__(self):
        self.path = DefaultPath()
        
        global OGR_PATH, SQLITE_PATH 
        OGR_PATH = self.path.getOgr2ogrPath()    
        SQLITE_PATH =  self.path.getSqliteDBPath()

    
    def sqliteImport(self, filePath, saveName, encoding="CP949"):
        arg = f''' "{OGR_PATH}" -f SQLite -dsco SPATIALITE=YES "{SQLITE_PATH}" "{filePath}" -nlt PROMOTE_TO_MULTI 
                    -overwrite --config SHAPE_ENCODING {encoding} -nln "{saveName}" '''.replace("\n", "")        

        return callExecute(arg)
    
    
    
    
    
    
    
   