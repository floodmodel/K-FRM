import sys
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

from PyQt5.QtWidgets import QDialog, QVBoxLayout, QComboBox


class GraphDialog(QDialog):
    def __init__(self, tbl, parent=None):
        super(GraphDialog, self).__init__(parent) 

        self.table = tbl
        self.initUI()
        
        self.setLayout(self.layout)
        self.resize(800, 600)

        self.exec_()
                 
    def initUI(self):
        self.setGraphFont()
        
        self.fig = plt.Figure()
        self.canvas = FigureCanvas(self.fig)

        self.columnCount = self.table.columnCount()
        rowCount = self.table.rowCount()
        headers = [self.table.horizontalHeaderItem(i).text() for i in range(self.columnCount)]
        self.valueCount = headers.index("0")
        self.xLabel = headers[self.valueCount:]
        selectItems = []
        for i in range(rowCount):
            items = self.table.item(i, 0).text()
            if self.valueCount==3:
                t = self.table.item(i, 1).text()
                items += f"({t})" if t.strip()!="" else ""
            selectItems.append(items)
        
        self.cmb = QComboBox()
        self.cmb.addItems(selectItems)
        self.cmb.activated.connect(self.drawGraph)

        self.layout = QVBoxLayout()
        self.layout.addWidget(self.canvas)
        self.layout.addWidget(self.cmb)
        self.drawGraph(0)
 
    def setGraphFont(self): #matplotlib에서 한글 폰트가 없어 한글이 깨지기 때문에 폰트를 지정해 줌.
        try:
            location='C://Windows/Fonts/malgun.ttf'
            font_name = fm.FontProperties(fname = location).get_name()
            matplotlib.rc('font', family = font_name)
        except Exception as e:
            print(e)
 
    def drawGraph(self, index):             
        itemText = self.cmb.currentText()
        
        self.fig.clear()
 
        ax = self.fig.add_subplot(111)
#         for j, h in enumerate(self.headers): #전체 값 한번에
#             y = [float(self.table.item(j, i).text()) for i in range(2, self.columnCount)]
#             ax.plot(self.xLabel, y, label=h)
        y = [float(self.table.item(index, i).text()) for i in range(self.valueCount, self.columnCount)]
        ax.plot(self.xLabel, y, label=itemText)
        
        ax.set_xlabel("침수심")
        ax.set_ylabel("손상률")
        ax.set_ylim(0, 101)
        ax.set_title("침수심 & 손상률")
#         for label in ax.xaxis.get_ticklabels() : #X축 라벨 기울기
#             label.set_rotation(45)
        """
        ncol = int - 레전드 목록 열 개수 지정
        loc = string - 레전드 목록 위치 지정("center left")...
        bbox_to_anchor = double, double - 레전드 목록 자리 조정(x, y축 1이상은 그래프 밖 위치임) 
        """
        ax.legend() 
        self.canvas.draw()

    
