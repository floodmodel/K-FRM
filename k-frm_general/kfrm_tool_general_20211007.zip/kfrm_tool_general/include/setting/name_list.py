#SQLite에 저장될 테이블이름들 
LAYER_FLOOD = "flood_table_list"
RECLASS_TABLE = "reclass_field_table"

#침수지 shp
T_FLOOD = "flood_area"                          #침수 구역도
F_RESULT = "flood_sum_result"

#Building 관련
INV_BUILDING = "inv_building"                   # 건물 인벤토리
B_ENTRACE = "building_entrance"                  # 출입구 높이 값
B_DEPRECIATION = "building_depreciation"        # 감가상각률 값
B_COSTS = "building_costs"                      # 건물단가 값
B_CSVR = "building_csvr"                        # csvr 값
B_SDAMAGE = "building_structure_damage_rate"    # 건물 구조 손상률 값
B_IDAMAGE = "building_inner_damage_rate"        # 건물 내부 손상률 값
B_VALUE = "building_valuation_result"

#Population 관련
INV_POPULATION = "inv_population"
P_LIFE = "population_life_loss"
P_VICTIM = "population_victim_loss"
# P_OCCURRENCE = "population_occurrence_probability"
P_COSTS = "population_unit_cost"


#Farmland 관련
INV_FARMLAND = "inv_agriculture"
A_CDAMAGE = "agriculture_crop_dmg_func"
A_FDAMAGE = "agriculture_frm_dmg_func"
A_MPRIFLOW = "agriculture_stdr_price_flow"
A_PRIFLOW = "agriculture_price_flow"
A_DUNIT = "agriculture_unit_cost"


#Vehicle 관련
INV_VEHICLE = "inv_vehicle"
V_VULFUNC = "vehicle_dmg_func"

#python 코드 dic 이름 관련 
B_PARAM = "building parameter"
B_SUMRIZ = "building summarize"
B_VUL = "building vulnerability"
P_PARAM = "population parameter"
P_VUL = "population vulnerability"
A_PARAM = "agriculture parameter"
A_VUL = "agriculture vulnerability"
A_SUMRIZ = "agriculture summarize"
V_PARAM = "vehicle parameter"
V_VUL = "vehicle vulnerability"

#tableHeader 관련 
# h_dmg_func = ['0m', '0-0.3m', '0.3-0.6m', '0.6-0.9m', '0.9-1.2m', '1.2-1.5m', '1.5-1.8m', '1.8-2.1m', '2.1-2.4m', '2.4-2.7m', '2.7-3.0m', '3.0m-']
# TABLE_HEADER_DIC = {
#     B_COSTS : ['Occupancy', 'Description', 'Costs (1,000KW/㎡)'],
#     B_CSVR : ['Occupancy', 'CSVR (%)'],
#     B_DEPRECIATION : ['Occupancy', 'Description', 'Persisting Period (yr)'],
#     B_ENTRACE : ['Occupancy', 'First Floor Elevation (m)'],
#     B_IDAMAGE : ['Occupancy']+h_dmg_func,
#     B_SDAMAGE : ['Occupancy', 'Description']+h_dmg_func,
#     P_LIFE : ['Hierarchy']+h_dmg_func,
#     P_VICTIM : ['Hierarchy']+h_dmg_func,
#     A_CDAMAGE : ['Farmland', 'Crops']+h_dmg_func,
#     A_FDAMAGE : ['Farmland']+h_dmg_func,
#     A_MPRIFLOW : ['Farmland', 'Crops', 'May', 'Jun', 'Jul', 'Aug'],
#     A_PRIFLOW : ['Farmland', 'Crops', 'stndr_prd_cst', 'stndr_income', 'input_prd_cst', 'expct_netpr'],
#     V_VULFUNC : ['Type']+h_dmg_func,
# } 
