# -*- coding: utf-8 -*-
import os
import sys

# 2019-04-05 박: 프로그램 개발에 앞서 내부 모듈에서 사용하는 함수 정리해두기     
    
# 파일 존재 여부 체크 함수
def ChFile_Exists(file):
    return os.path.exists(file)
    
# 파일 이름 받아오기 함수
def GetFile_Name(file):
    FileName = os.path.basename(file)
    return FileName
    
# 파일 경로 받아 오기(파일명 제외함)
def GetFileDirectory_Path(file):
    return os.path.dirname(file)

# 프로그램의 실행 경로를 받아옴 
def GetScriptDirectory_Path():
    scriptDirectory = os.path.dirname(os.path.realpath(__file__))
    return scriptDirectory

# 파일 전체를 읽어서 파일 내용을 한번에 반환 
def GetRead_Txt(file):
    f = open(file, 'r')
    AllText = f.read()
    f.close()
    return AllText

def GetFileType(filename):
    return os.path.splitext(filename)[1]

#지정 폴더의 하위 내용을 읽어 파일 리스트 반환
def GetSubFolder_List(targetFolder, extension=""):    
    fileList = []
    
    for path, dirs, files in os.walk(targetFolder):    
        if files: #빈값인지 확인 가능
            if extension: #파일 종류 확인 후 거르기 
                l = [os.path.join(path, fileName) for fileName in files 
                     if fileName.endswith(extension) and "삭제" not in fileName]
            else: 
                l = [os.path.join(path, fileName) for fileName in files if "삭제" not in fileName]
        
            fileList+=l
        
    return fileList