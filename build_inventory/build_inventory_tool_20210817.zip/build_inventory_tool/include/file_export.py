import os

from ..lib.Util import *
from .path_list import *

class FileExport:
    #ogr2ogr.exe 프로그램을 사용하여 결과 테이블의 모든 정보를 검색하고 shape 파일로 출력.
    def shapeExport(self, savePath, tableName, encoding="UTF-8", column="*", pkOption=""):
        savePath = self.overlapFileName(savePath)
    #     arg = ('"{}" {} -f "ESRI Shapefile" "{}" "{}" -sql "SELECT {} FROM \'{}\'" --config SHAPE_ENCODING {} -lco ENCODING={}'
    #                   .format(OGR_PATH, pkOption, savePath, DB_PATH, column, tableName, encoding)).replace("\n", "")
        arg = f"""
            "{OGR_PATH}" {pkOption} -f "ESRI Shapefile" "{savePath}" "{DB_PATH}" 
                -sql "SELECT {column} FROM '{tableName}'" --config SHAPE_ENCODING {encoding} -lco ENCODING={encoding}
        """.replace("\n", "").replace("\t", "")

        return callExecute(arg)
    
    
    def overlapFileName(self, path):
        osIsfile = os.path.isfile
        osSplit= os.path.split
        osSpliText = os.path.splitext
        
        if osIsfile(path):
            flag = True
            j = 1
            while(flag):
                j +=1
                folder, filename = osSplit(path)
                filename, extension = osSpliText(filename)
                
                splitCount = len(str(j))+3
                splitName = f" ({str(j)})"
                if filename[-splitCount:]==splitName:
                    filename = filename[:-splitCount]
                
                rePath = f"{folder}/{filename}{splitName}{extension}"
                
                if not osIsfile(rePath):
                    path = rePath
                    flag = False
                    
        return path