# -*- coding: utf-8 -*-
import sqlite3
from shutil import copyfile

from ..lib.File_Class import *
from .path_list import *

"""
   DB Connection 클래스를 싱글톤으로 구성하여 
   여러 클래스에서 SQLiteConnection을 호출하여도 초기에 호출된 한번만 Connection이 걸리고 
    후에 호출 되어도 Connection이 걸리지 않도록 구성. 
"""

class SingleTon(type):
    _instances = {}
    
    def __call__(self, *args, **kwargs):
        if self not in self._instances:
            self._instances[self] = super(SingleTon, self).__call__(*args, **kwargs)
        return self._instances[self]
    
class SQLiteConnection(object, metaclass=SingleTon):
    def __init__(self):
        self.connectionDB()

    def isDB(self):
        if not ChFile_Exists(DB_PATH):
            copyfile(EMPTY_DB, DB_PATH)
    
    def connectionDB(self):
        self.isDB() #DB 존재 유무 체크

        global _connection, _cursor
        _connection = sqlite3.connect(DB_PATH, check_same_thread=False)
        _connection.enable_load_extension(True)
        _connection.load_extension('mod_spatialite')
        _cursor = _connection.cursor()
        
        return _connection, _cursor
        
    def closeDB(self):
        _connection.close()    
        
    def clearDB(self): #인벤토리 구축하면서 사용했던 테이블 내용 지우기.
        sql = """
            PRAGMA writable_schema = 1;
            DELETE FROM sqlite_master WHERE (name like "%car%" or 
                                name like "%popu%" or name like "%farm%" or 
                                name like "%build%" or name like "%integrated%");
            DELETE FROM geometry_columns;
            DELETE FROM geometry_columns_auth;
            DELETE FROM geometry_columns_statistics;
            DELETE FROM geometry_columns_field_infos;
            DELETE FROM spatialite_history;
            DELETE FROM sqlite_sequence WHERE name!="spatialite_history";
            DELETE FROM geometry_columns_time;
            PRAGMA writable_schema = 0;
        """        
        self.excScript(sql)
        self.excNone("Vacuum;") #sql문에 한꺼번에 넣어 실행하면 오류남.
            
    def commit(self):
        _connection.commit()
    
    def exeDecorator(func):
        def decorated(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except sqlite3.Error as e:
                _connection.rollback()
                raise sqlite3.Error(e)
        return decorated

    @exeDecorator
    def excValue(self, query): # retrun 값 있음 : select
        _cursor.execute(query)
        return _cursor.fetchall()
    
    @exeDecorator
    def excNone(self, query): # return 값 없음 : update, insert, delete...
        _cursor.execute(query)
        self.commit()
    
    @exeDecorator
    def excMany(self, query, content): # insert시 한번에 값 여러개 넣기 ([1], [1]) <-이런 형태로 전달 해야 함.
        _cursor.execute("BEGIN TRANSACTION;")
        _cursor.executemany(query, tuple(content))
        _cursor.execute("END TRANSACTION;")
        self.commit()
    
    @exeDecorator
    def excQueryMany(self, query): #여러개의 쿼리를 날릴때 한꺼번에 쿼리를 날리고 후에 Commit. 
        for q in query:
            _cursor.execute(q)
        
        self.commit()
    
    @exeDecorator
    def excScript(self, query): #여려개의 쿼리를 한번에 날릴 때. 하나의 쿼리가 끝나면 ;으로 표시. 위 excQueryMany 대용.
        _cursor.executescript(query)
        self.commit()
