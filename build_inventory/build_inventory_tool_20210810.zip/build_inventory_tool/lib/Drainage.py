# -*- coding: utf-8 -*-
import os
from .Util import *
import tempfile



class TaudemArg:
    def __init__(self):
        global tauPath,output_Temp
        tauPath="C:/Program Files/TauDEM/TauDEM5Exe/"
        output_Temp =tempfile.mktemp() + ".tif"

    # 2019-04-17 박:인터넷 찾아보니 QGIS 지원에서 제외됨 Qgis 2.xx 버전은 지원됨 
    # 현재는 Taudem을 설치 해야됨  
    # fill_sink 
    def SK(self,input,output):
        tau =tauPath +  "PitRemove.exe"
        arg = '"' + tau + '"' + ' -z ' + '"' + input + '"' + ' -fel ' + '"' + output + '"'
        return arg

    # Flow direction
    def FD(self,input,output):
        tau = tauPath + "D8FlowDir.exe"
        arg = '"' + tau + '"' + ' -fel ' + '"' + input + '"' + ' -p ' + '"' + output + '"' + ' -sd8 ' + '"' + output_Temp + '"'
        return arg

    #flow accumulation(대충맞을거 같음 모르면 찾아봐)
    def FA(self,input,output):
        tau = tauPath + "AreaD8.exe"
        #옵션 2개중에 한개 (엣지 넣기 안넣기)
        arg = '"' + tau + '"' + ' -p ' + '"' + input + '"' + ' -ad8 ' + '"' + output + '"'
        #arg = '"' + tauPath + '"' + ' -p ' + '"' + input + '"' + ' -ad8 ' + '"' + output + '"' + ' -nc '
        return arg

    # slope greed
    def SG(self,input,output):
        tau = tauPath + "D8FlowDir.exe"
        arg = '"' + tau + '"' + ' -fel ' + '"' + input + '"' + ' -p ' + '"' + output_Temp + '"' + ' -sd8 ' + '"' + output + '"'
        return arg    

    # stream vector
    def ST(self,input,output):
        tau = tauPath + "Threshold.exe"
        arg ='"' + tau + '"' + ' -ssa '  + '"' + input + '"' + ' -src ' + '"' + output + '"' + ' -thresh ' +  option
        return arg
