import codecs

from PyQt5.QtWidgets import QApplication

from ..connectDB import SQLiteConnection
from ..table_names import *

class Integrated:
    def __init__(self):
        global _DB, COUNT_ERROR, COLUMN_ERROR, INDEX_ERROR
        _DB = SQLiteConnection()
        
    ## Create
    def createIntegratedBCode(self, values): #법정동 코드 테이블
        try:
            del values[0]
            sql = """
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        CODE VARCHAR,
                        SIDO VARCHAR,
                        SGG VARCHAR,
                        EMD VARCHAR,
                        DL VARCHAR,
                        CREATE_DAY VARCHAR,
                        DELETE_DAY VARCHAR
                    );
                """.format(INTEGRATED_BCODE, INTEGRATED_BCODE)
            in_sql = "INSERT INTO {} VALUES({});".format(INTEGRATED_BCODE, ("?,"*7)[:-1])
                
            _DB.excScript(sql)
            _DB.excMany(in_sql, values)
        except Exception as e:
            e = str(e).lower()
            if (COUNT_ERROR in e) or (COLUMN_ERROR in e) or (INDEX_ERROR in e):
                raise Warning("입력하신 법정동 코드 자료에 오류가 있습니다.")
            raise Warning(e)
    
    def createIntegratedAge(self, txtPath): #성 연령별 인구 테이블
        try:
            sql = """
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        BASE_YEAR CHAR(4),
                        TOT_OA_CD CHAR(13),
                        ITEM VARCHAR(255),
                        VALUE NUMERIC
                    );
                """.format(INTEGRATED_AGE, INTEGRATED_AGE)
                
            _DB.excScript(sql)
            try: 
                with codecs.open(txtPath, 'r', 'cp949') as f:
                    self.insertData(INTEGRATED_AGE,  f)    
            except UnicodeDecodeError:
                with codecs.open(txtPath, 'r', 'utf-8') as f:
                    self.insertData(INTEGRATED_AGE,  f)    
            
        except Exception as e:
            e = str(e).lower()
            if (COUNT_ERROR in e) or (COLUMN_ERROR in e) or (INDEX_ERROR in e):
                raise Warning("입력하신 성 연령별 인구 자료에 오류가 있습니다.")
            raise Warning(e)
    
    
    ## Update
    def addGeometry(self, originTable, targetTable, pk1, pk2): #Geometry 추가
        #Geometry를 Insert select 때 함께 넣어서 recovergeometrycolumn을 사용해도 상관없으나, 
        #위 방법을 사용하면 Geometry 컬럼의 타입이 정상적으로 표기되지 않음.
        gm_sql = 'SELECT * FROM geometry_columns WHERE f_table_name="{}";'
        
        tableName, geom, type, coord, srid, _ = _DB.excValue(gm_sql.format(originTable.lower()))[0]
        geomList = ['GEOMETRY', 'POINT', 'LINESTRING', 'POLYGON', 'MULTIPOINT', 'MULTILINESTRING', 'MULTIPOLYGON', 'GEOMETRYCOLLECTION']
        coord = 'XY' if coord==2 else 'XYZ' if coord==3 else 'XYZM'

        ag_sql = 'select addgeometrycolumn("{}", "{}", {}, "{}", "{}")' #테이블, geom 컬럼명, 공간좌표, 도형, 차원
        ut_sql = '''
            BEGIN TRANSACTION;
            DROP INDEX IF EXISTS idx_popu_origin;                    
            CREATE INDEX idx_popu_origin ON {}({});
            update "{}" as A set "{}"=(select B."{}" from "{}" as B where A."{}"=B."{}");
            END TRANSACTION;
        '''.format(tableName, pk1, targetTable, geom, geom, tableName, pk1, pk2)

        _DB.excNone(ag_sql.format(targetTable, geom, srid, geomList[type], coord))
        _DB.excScript(ut_sql)
        
    def recoverGeometry(self, originTable, targetTable): #기존 geometry 값 복구
        gm_sql = 'SELECT * FROM geometry_columns WHERE f_table_name="{}";'
        ag_sql = 'SELECT recovergeometrycolumn("{}", "{}", {}, "{}", "{}")' #테이블, geom 컬럼명, 공간좌표, 도형, 차원
        spatial_sql = "SELECT CreateSpatialIndex('{}', '{}');" #테이블, geom 컬럼명
        
        tableName, geom, type, coord, srid, _ = _DB.excValue(gm_sql.format(originTable.lower()))[0]
        geomList = ['GEOMETRY', 'POINT', 'LINESTRING', 'POLYGON', 'MULTIPOINT', 'MULTILINESTRING', 'MULTIPOLYGON', 'GEOMETRYCOLLECTION']
        coord = 'XY' if coord==2 else 'XYZ' if coord==3 else 'XYZM'
        
        _DB.excNone(ag_sql.format(targetTable, geom, srid, geomList[type], coord))
        _DB.excNone(spatial_sql.format(targetTable, geom))
    
    
    ## Insert  
    def insertData(self, tableName, fileValue, columnCount=4, separator="^"): 
        in_sql = "INSERT INTO {} VALUES({});".format(tableName, ("?,"*columnCount)[:-1])
        
        fileValue.readline() #제목 버림
        values=[]
        QApplication.processEvents()
        for i, value in enumerate(fileValue):
            if i%5000==0: #과부화 걸리지 않도록 중간중간 데이터 삽입
                QApplication.processEvents()
                _DB.excMany(in_sql, values)
                values = []
            
            l = value.split(separator)
            l[-1] = l[-1].replace("\n","") #줄 끝에 있는 개행문자 제거
            values.append(l)

        _DB.excMany(in_sql, values)
    
    
    ## Select
    def isTabled(self, tableName): #테이블이 존재하는지 확인
        sql = f"SELECT * FROM sqlite_master WHERE tbl_name='{tableName}' collate nocase AND type='table';"
        return _DB.excValue(sql)
    
    def isColumns(self, tableName, columns): #테이블에서 특정 칼럼이 존재하는지 확인
        try:
            sql = f"SELECT {columns} FROM '{tableName}' limit 1;"
            _DB.excValue(sql)
        except Exception as e:
            raise Warning(e)
        
    def countRow(self, tableName): #테이블의 행 개수 확인
        sql = f"SELECT count(rowid) FROM {tableName};"
        return _DB.excValue(sql)
    