import codecs

from PyQt5.QtWidgets import QApplication

from ..connectDB import SQLiteConnection

from ..table_names import *
from ...lib.File_Class import *
# from ..file_import import FileImport
from .inventory_DAO import Integrated
from ..error_list import ErrorList

class Building:
    def __init__(self):
        global _DB
        _DB = SQLiteConnection()
        self.inv = Integrated()
        self.error = ErrorList()
        
    def createBuild(self): #결과 테이블
        try:
            sql = """
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        OGC_FID INTEGER PRIMARY KEY,
                        L_ADMIN TEXT,
                        S_BDTYP TEXT,
                        BDTYP TEXT,
                        S_BDSTR TEXT,
                        BDSTR TEXT,
                        BD_F_AREA REAL,
                        GRO_FLO_CO INTEGER,
                        UND_FLO_CD INTEGER,
                        RA_USE_YEAR TEXT,
                        USE_YEAR TEXT, 
                        SIG_CD TEXT,
                        EMD_CD TEXT,
                        LI_CD TEXT,
                        MNTN_YN TEXT,
                        LNBR_MNNM TEXT,
                        LNBR_SLNO TEXT,
                        BULD_NM_DC TEXT,
                        MAT_RES TEXT
                    );
                """.format(BUILD_TABLE_NAME, BUILD_TABLE_NAME)
                
            _DB.excScript(sql)
            self.createBuildInfo()
            self.selectBuildResult()
        except Exception as e:
            raise Warning(str(e))
    
    def createBuildPurpose(self, values): #건물 용도 테이블
        try:
            del values[0]
            sql = """
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        BDTYP_CD NUMERIC,
                        BDTYP_OLD TEXT,
                        BDTYP TEXT
                    );
                """.format(BUILD_PURPOSE_TABLE, BUILD_PURPOSE_TABLE)
            in_sql = "INSERT INTO {} VALUES({});".format(BUILD_PURPOSE_TABLE, ("?,"*3)[:-1])
                
            _DB.excScript(sql)
            _DB.excMany(in_sql, values)
        except Exception as e:
            self.error.wrongFileMsg(e, "건물 코드 정의")
            raise Warning(str(e))

    def createBuildStructure(self, values): #건물 구조 테이블
        try:
            del values[0]
            sql = """
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        BDSTR_CD NUMERIC,
                        BDSTR_OLD TEXT,
                        BDSTR TEXT
                    );
                """.format(BUILD_STRUCTURE_TABLE, BUILD_STRUCTURE_TABLE)
            in_sql = "INSERT INTO {} VALUES({});".format(BUILD_STRUCTURE_TABLE, ("?,"*3)[:-1])
                 
            _DB.excScript(sql)
            _DB.excMany(in_sql, values)
        except Exception as e:
            self.error.wrongFileMsg(e, "건물 코드 정의")
            raise Warning(str(e))

    def createBuildTitle(self, filePath): #표제부 테이블
        try:
            sql = """
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        OGC_FID INTEGER,
                        SIG_CD TEXT,
                        BJD_CD TEXT,
                        MNTN_YN TEXT,
                        B_CD TEXT, 
                        J_CD TEXT,
                        BULD_NM_DC TEXT, 
                        BD_F_AREA NUMERIC,
                        BD_TOTAL_AREA NUMERIC,
                        BDSTR_CD TEXT,
                        S_BDSTR TEXT,
                        BDSTR TEXT,
                        GRO_FLO_CO NUMERIC,
                        UND_FLO_CO NUMERIC,
                        USE_DAY TEXT,
                        PNU TEXT, 
                        PNU_BULD TEXT
                    );
                """.format(BUILD_TITLE_TABLE, BUILD_TITLE_TABLE)
                
            up_sql = """
                UPDATE {} as A SET BDSTR = (SELECT BDSTR FROM {} as B WHERE A.BDSTR_CD = B.BDSTR_CD);
            """.format(BUILD_TITLE_TABLE, BUILD_STRUCTURE_TABLE)
            
            _DB.excScript(sql)
            if GetFileType(filePath)==".txt":
                try : 
                    with codecs.open(filePath, 'r', 'cp949') as f:
                        self.insertBuildTitle(f)    
                except UnicodeDecodeError:
                    with codecs.open(filePath, 'r', 'utf-8') as f:
                        self.insertBuildTitle(f)    
            else:
                values = excelRead(filePath)
                self.insertBuildTitle(values)
                
            _DB.excNone(up_sql)
        except Exception as e:
            self.error.wrongFileMsg(e, "건축물 대장 표제부")
            raise Warning(str(e))
    
    def createBuildInfo(self): #shape 내용 + 건물 용도 
        try:
            pnu_txt = """A.'SIG_CD'||A.'EMD_CD'||A.'LI_CD'||A.'MNTN_YN'
                        ||substr('0000'||A.'LNBR_MNNM', -4, 4)||substr('0000'||A.'LNBR_SLNO', -4, 4)"""

            sql = ("""
                    UPDATE {} SET BDTYP_CD='07000' WHERE BDTYP_CD='07199';               
                """.format(BUILD_ORIGIN_TABLE)
                +
                """
                    DROP TABLE IF EXISTS TEMP_BUILD_INFO;
                    CREATE TEMP TABLE IF NOT EXISTS TEMP_BUILD_INFO (
                            OGC_FID INTEGER,
                            L_ADMIN TEXT,
                            BDTYP_CD TEXT,
                            S_BDTYP TEXT,
                            BDTYP TEXT,
                            SIG_CD TEXT,
                            EMD_CD TEXT,
                            LI_CD TEXT,
                            MNTN_YN TEXT,
                            LNBR_MNNM TEXT, 
                            LNBR_SLNO TEXT,
                            GRO_FLO_CO NUMERIC,
                            UND_FLO_CO NUMERIC,
                            BULD_NM_DC TEXT,
                            PNU TEXT,
                            PNU_BULD TEXT
                    );
                """
                +
                """
                    INSERT INTO TEMP_BUILD_INFO 
                        SELECT A.OGC_FID, C.SIDO||' '||C.SGG||' '||C.EMD||' '||C.DL, A.'BDTYP_CD', B.'BDTYP_OLD', B.'BDTYP',
                            A.'SIG_CD', A.'EMD_CD', A.'LI_CD', A.'MNTN_YN', 
                            substr('0000'||A.LNBR_MNNM, -4, 4), substr('0000'||A.LNBR_SLNO, -4, 4), 
                            A.'GRO_FLO_CO', A.'UND_FLO_CO', A.'BULD_NM_DC', {}, 
                            CASE WHEN A.'BULD_NM_DC' is null THEN {} ELSE {}||replace(A.'BULD_NM_DC', ' ','') END
                        FROM '{}' as A, '{}' as B, '{}' as C
                        WHERE A.'BDTYP_CD' = substr('00000'||B.BDTYP_CD, -5, 5) and A.'SIG_CD'||A.'EMD_CD'||A.'LI_CD'=C.CODE;
                """.format(pnu_txt, pnu_txt, pnu_txt,
                           BUILD_ORIGIN_TABLE, BUILD_PURPOSE_TABLE, INTEGRATED_BCODE)
                +
                """
                    DROP TABLE IF EXISTS INFO_BUILD_OVERAP;
                    CREATE TEMP TABLE INFO_BUILD_OVERAP as
                        SELECT PNU_BULD FROM TEMP_BUILD_INFO GROUP BY PNU_BULD HAVING count(PNU_BULD)>1;
                    DROP TABLE IF EXISTS INFO_PNU_OVERAP;
                    CREATE TEMP TABLE INFO_PNU_OVERAP as
                        SELECT PNU FROM TEMP_BUILD_INFO GROUP BY PNU HAVING count(PNU)>1;
                """
                +
                f"""
                    DROP TABLE IF EXISTS {BUILD_INFO_TABLE};
                    CREATE TABLE IF NOT EXISTS {BUILD_INFO_TABLE} as 
                        SELECT *,
                            CASE WHEN PNU in INFO_PNU_OVERAP THEN
                                CASE WHEN PNU_BULD in INFO_BUILD_OVERAP THEN '00' ELSE '01' END                            
                            ELSE
                                CASE WHEN PNU_BULD in INFO_BUILD_OVERAP THEN '10' ELSE '11' END
                            END as MAT_RES
                        FROM TEMP_BUILD_INFO;
                """
            )
            
            _DB.excScript(sql)
            self.inv.addGeometry(BUILD_ORIGIN_TABLE, BUILD_INFO_TABLE, "ogc_fid", "ogc_fid")
        except Exception as e:
            self.error.wrongFileMsg(e, "도로명 주소 기본도")
            raise Warning(str(e))    
    
    
    def insertBuildTitle(self, fileValue):
        in_sql = """ INSERT INTO {}(OGC_FID, SIG_CD, BJD_CD, MNTN_YN, B_CD, J_CD, BULD_NM_DC, 
            BD_F_AREA, BD_TOTAL_AREA, BDSTR_CD, S_BDSTR, GRO_FLO_CO, UND_FLO_CO, 
            USE_DAY, PNU, PNU_BULD) VALUES({});""".format(BUILD_TITLE_TABLE, ("?,"*16)[:-1])
        
        values=[]
        valueIndex=[]
        titleList = ['시군구코드', '법정동코드', '대지구분코드', '번', '지', '동명', "동명칭", '건축면적(㎡)', '연면적(㎡)', '구조코드', 
                     '구조코드명', '지상층수', '지하층수', '사용승인일'] #전국 표제부 텍스트는 '동_명', 지자체 표제부 엑셀파일은 '동명칭'으로 표기되어 있음

        try:
            #파일이 Text 일 때 
            titleValue = [value.replace("_", "").strip()  for value in fileValue.readline().split("|")]

            for title in titleList:
                for i, c in enumerate(titleValue):
                    if title==c:
                        valueIndex.append(i)
                        break;
            
            QApplication.processEvents()                   
            for i, value in enumerate(fileValue):
                if i%5000==0:
                    QApplication.processEvents()
                    _DB.excMany(in_sql, values)
                    values = []
                    
                row = value.split("|")
                l = [row[j] for j in valueIndex]
        
                values.append([i]+l+["".join(l[:5]), "".join(l[:6]).replace(" ", "")])
            _DB.excMany(in_sql, values)
            
        except AttributeError:
            #파일이 Excel 일 때 
            titleValue = [value.replace("_", "").strip()  for value in fileValue[0]]
            del fileValue[0] #파일 내용을 넣을 때 제목은 넣지 않도록 삭제
            for title in titleList:
                for i, c in enumerate(titleValue):
                    if title==c:
                        valueIndex.append(i)
                        break;
            
            QApplication.processEvents()        
            for i, value in enumerate(fileValue):
                if i%5000==0:
                    QApplication.processEvents()
                    _DB.excMany(in_sql, values)
                    values = []
    
                l = [value[j] for j in valueIndex]
                values.append([i]+l+["".join(l[:5]), "".join(l[:6]).replace(" ", "")])
            _DB.excMany(in_sql, values)
            
            
    def selectBuildResult(self): #결과 도출
        try:
            sql = (f"""
                    BEGIN TRANSACTION;
                    DROP TABLE IF EXISTS TEMP_SIG_TITLE;
                    CREATE TEMP TABLE TEMP_SIG_TITLE as
                        SELECT * FROM {BUILD_TITLE_TABLE} WHERE SIG_CD IN (SELECT SIG_CD FROM {BUILD_INFO_TABLE} GROUP BY SIG_CD);
                        
                    DROP TABLE IF EXISTS TITLE_BUILD_OVERAP;
                    CREATE TEMP TABLE TITLE_BUILD_OVERAP as
                        SELECT PNU_BULD FROM TEMP_SIG_TITLE GROUP BY PNU_BULD HAVING count(PNU_BULD)>1;
                    DROP TABLE IF EXISTS TITLE_PNU_OVERAP;
                    CREATE TEMP TABLE TITLE_PNU_OVERAP as
                        SELECT PNU FROM TEMP_SIG_TITLE GROUP BY PNU HAVING count(PNU)>1;
                    
                    DROP TABLE IF EXISTS SIG_TITLE;
                    CREATE TEMP TABLE SIG_TITLE as
                        SELECT *,
                            CASE WHEN PNU in TITLE_PNU_OVERAP THEN
                                CASE WHEN PNU_BULD in TITLE_BUILD_OVERAP THEN '00' ELSE '01' END                            
                            ELSE
                                CASE WHEN PNU_BULD in TITLE_BUILD_OVERAP THEN '10' ELSE '11' END
                            END as MAT_RES
                        FROM TEMP_SIG_TITLE;
                """ #표제부 테이블에서 시군구 지역 값만 추출(예 : 강원도 원주시)
                +
                f"""
                    DROP TABLE IF EXISTS BUILD_RESULT1;
                    CREATE TEMP TABLE BUILD_RESULT1 as 
                        SELECT A.OGC_FID, A.L_ADMIN, A.S_BDTYP, A.BDTYP, B.S_BDSTR, B.BDSTR, 
                            CASE WHEN B.BD_F_AREA=0 or B.BD_F_AREA is NULL 
                                THEN B.BD_TOTAL_AREA/(B.GRO_FLO_CO+B.UND_FLO_CO) ELSE B.BD_F_AREA END as BD_F_AREA, 
                            B.GRO_FLO_CO, B.UND_FLO_CO, B.USE_DAY, substr(B.USE_DAY,1,4) as USE_YEAR,
                            A.SIG_CD, A.EMD_CD, A.LI_CD, A.MNTN_YN, A.LNBR_MNNM, A.LNBR_SLNO, A.BULD_NM_DC, 
                            CASE WHEN B.OGC_FID is NOT NULL THEN A.MAT_RES||' 1단계 연계' ELSE NULL END as MAT_RES
                        FROM {BUILD_INFO_TABLE} as A LEFT JOIN SIG_TITLE as B 
                            ON A.PNU=B.PNU and A.MAT_RES='11' and A.MAT_RES=B.MAT_RES GROUP BY A.OGC_FID;
                """
                +
                #1:0 2단계 연계
                f"""
                    DROP TABLE IF EXISTS BUILD_RESULT2;
                    CREATE TEMP TABLE BUILD_RESULT2 as 
                        SELECT A.OGC_FID, A.L_ADMIN, A.S_BDTYP, A.BDTYP, B.S_BDSTR, B.BDSTR, 
                            CASE WHEN B.BD_F_AREA=0 or B.BD_F_AREA is NULL 
                                THEN B.BD_TOTAL_AREA/(B.GRO_FLO_CO+B.UND_FLO_CO) ELSE B.BD_F_AREA END as BD_F_AREA, 
                            B.GRO_FLO_CO, B.UND_FLO_CO, B.USE_DAY, substr(B.USE_DAY,1,4) as USE_YEAR,
                            A.SIG_CD, A.EMD_CD, A.LI_CD, A.MNTN_YN, A.LNBR_MNNM, A.LNBR_SLNO, A.BULD_NM_DC, 
                            CASE WHEN B.OGC_FID is NOT NULL THEN A.MAT_RES||' 2단계 연계' ELSE NULL END as MAT_RES
                        FROM {BUILD_INFO_TABLE} as A LEFT JOIN SIG_TITLE as B 
                            ON A.PNU_BULD=B.PNU_BULD and A.MAT_RES='01' and A.MAT_RES=B.MAT_RES GROUP BY A.OGC_FID;
                """
                +
                 #매칭되지 않은 객체들의 사용승인일 값은 모두 평균 값을 사용하기 위한 테이블
                 """
                     UPDATE SIG_TITLE SET USE_DAY=NULL WHERE USE_DAY="";
                     DROP TABLE IF EXISTS AVG_SIG_TITLE;
                     CREATE TEMP TABLE AVG_SIG_TITLE as
                         SELECT OGC_FID, PNU, S_BDSTR, BDSTR, cast(avg(USE_DAY) as INT) as USE_DAY FROM SIG_TITLE GROUP BY PNU;
                 """
                 +
#                연계되지 않은 것들 3단계 연계
                 f"""
                     DROP TABLE IF EXISTS BUILD_RESULT3;
                     CREATE TEMP TABLE BUILD_RESULT3 as 
                         SELECT A.OGC_FID, A.L_ADMIN, A.S_BDTYP, A.BDTYP, B.S_BDSTR, B.BDSTR, area(A.GEOMETRY) as BD_F_AREA, 
                             A.GRO_FLO_CO, A.UND_FLO_CO, B.USE_DAY, substr(B.USE_DAY,1,4) as USE_YEAR,
                             A.SIG_CD, A.EMD_CD, A.LI_CD, A.MNTN_YN, A.LNBR_MNNM, A.LNBR_SLNO, A.BULD_NM_DC, 
                             CASE WHEN B.OGC_FID is NOT NULL THEN '3단계 연계' ELSE NULL END as MAT_RES
                         FROM {BUILD_INFO_TABLE} as A LEFT JOIN AVG_SIG_TITLE as B 
                             ON A.PNU=B.PNU GROUP BY A.OGC_FID;
                 """
                +
                """
                    DROP TABLE IF EXISTS BUILD_RESULT4;
                    CREATE TEMP TABLE BUILD_RESULT4 as 
                        SELECT A.OGC_FID, A.L_ADMIN, A.S_BDTYP, A.BDTYP,
                            CASE WHEN A.S_BDSTR<>"" THEN A.S_BDSTR ELSE 
                                CASE WHEN B.S_BDSTR<>"" THEN B.S_BDSTR ELSE C.S_BDSTR END END as S_BDSTR,
                            CASE WHEN A.BDSTR<>"" THEN A.BDSTR ELSE 
                                CASE WHEN B.BDSTR<>"" THEN B.BDSTR ELSE C.BDSTR END END as BDSTR,
                            CASE WHEN A.BD_F_AREA<>"" THEN A.BD_F_AREA ELSE 
                                CASE WHEN B.BD_F_AREA<>"" THEN B.BD_F_AREA ELSE C.BD_F_AREA END END as BD_F_AREA,
                            CASE WHEN A.GRO_FLO_CO<>"" THEN A.GRO_FLO_CO ELSE 
                                CASE WHEN B.GRO_FLO_CO<>"" THEN B.GRO_FLO_CO ELSE C.GRO_FLO_CO END END as GRO_FLO_CO,
                            CASE WHEN A.UND_FLO_CO<>"" THEN A.UND_FLO_CO ELSE 
                                CASE WHEN B.UND_FLO_CO<>"" THEN B.UND_FLO_CO ELSE C.UND_FLO_CO END END as UND_FLO_CO,
                            CASE WHEN A.USE_DAY<>"" THEN A.USE_DAY ELSE 
                                CASE WHEN B.USE_DAY<>"" THEN B.USE_DAY ELSE C.USE_DAY END END as RA_USE_YEAR,
                            CASE WHEN A.USE_YEAR<>"" THEN A.USE_YEAR ELSE 
                                CASE WHEN B.USE_YEAR<>"" THEN B.USE_YEAR ELSE C.USE_YEAR END END as USE_YEAR,
                            A.SIG_CD, A.EMD_CD, A.LI_CD, A.MNTN_YN, A.LNBR_MNNM, A.LNBR_SLNO, A.BULD_NM_DC,
                            CASE WHEN A.MAT_RES<>"" THEN A.MAT_RES ELSE 
                                CASE WHEN B.MAT_RES<>"" THEN B.MAT_RES ELSE C.MAT_RES END END as MAT_RES
                        FROM BUILD_RESULT1 as A, BUILD_RESULT2 as B, BUILD_RESULT3 as C 
                            WHERE A.OGC_FID=B.OGC_FID AND A.OGC_FID=C.OGC_FID GROUP BY A.OGC_FID;
                """ #RESULT1, 2 테이블을 매칭 및 중복제거 - 기본 베이스는 RESULT1                  
                +
                """
                    DROP TABLE IF EXISTS BUILD_RESULT_YEAR;
                    DROP TABLE IF EXISTS BUILD_TITLE_YEAR;
                    DROP TABLE IF EXISTS BUILD_TOTAL_YEAR;
                    CREATE TEMP TABLE BUILD_TITLE_YEAR as 
                        SELECT SIG_CD, BJD_CD, 
                            substr(round(avg(substr(USE_DAY||'0000', 1, 4)),0),1,4) as USE_YEAR 
                        FROM SIG_TITLE WHERE USE_DAY<>"" GROUP BY SIG_CD, BJD_CD;
                    CREATE TEMP TABLE BUILD_RESULT_YEAR as 
                        SELECT SIG_CD, EMD_CD||LI_CD as BJD_CD, 
                            substr(round(avg(USE_YEAR),0),1,4) as USE_YEAR 
                        FROM BUILD_RESULT4 WHERE USE_YEAR<>"" GROUP BY SIG_CD, EMD_CD, LI_CD;
                    CREATE TEMP TABLE BUILD_TOTAL_YEAR as
                        SELECT A.SIG_CD, A.BJD_CD,
                            CASE WHEN B.USE_YEAR<>"" THEN B.USE_YEAR ELSE A.USE_YEAR END as USE_YEAR
                        FROM BUILD_TITLE_YEAR as A LEFT JOIN BUILD_RESULT_YEAR as B 
                            ON A.SIG_CD=B.SIG_CD AND A.BJD_CD=B.BJD_CD;
                """ #읍면동 평균 사용승인년 테이블(1. 결과 테이블 기준 평균 / 2. 표제부 기준 평균)
                +
                f"""
                    INSERT INTO {BUILD_TABLE_NAME} 
                        SELECT B.OGC_FID, A.L_ADMIN, A.S_BDTYP, A.BDTYP,
                            CASE WHEN A.S_BDSTR is NULL or A.S_BDSTR="" THEN "철근콘크리트구조" ELSE A.S_BDSTR END as S_BDSTR,
                            CASE WHEN A.BDSTR is NULL or A.BDSTR="" THEN "철근콘크리트조" ELSE A.BDSTR END as BDSTR,
                            CASE WHEN A.BD_F_AREA is NULL or A.BD_F_AREA=0 THEN area(B.GEOMETRY) ELSE A.BD_F_AREA END,
                            CASE WHEN A.GRO_FLO_CO is NULL or A.GRO_FLO_CO=0 THEN 
                                CASE WHEN B.GRO_FLO_CO is NULL or B.GRO_FLO_CO=0 THEN 1 ELSE B.GRO_FLO_CO END
                                ELSE A.GRO_FLO_CO END,
                            CASE WHEN A.UND_FLO_CO is NULL or A.UND_FLO_CO=0 THEN 
                                CASE WHEN B.UND_FLO_CO is NULL or B.UND_FLO_CO=0 THEN 0 ELSE B.UND_FLO_CO END
                                ELSE A.UND_FLO_CO END,
                            A.RA_USE_YEAR,
                            CASE WHEN A.USE_YEAR is NULL or A.USE_YEAR="" THEN C.USE_YEAR else A.USE_YEAR END,
                            A.SIG_CD, A.EMD_CD, A.LI_CD, A.MNTN_YN, A.LNBR_MNNM, A.LNBR_SLNO,
                            CASE WHEN A.BULD_NM_DC is NULL THEN B.BULD_NM_DC ELSE A.BULD_NM_DC END, A.MAT_RES
                        FROM BUILD_RESULT4 as A, {BUILD_INFO_TABLE} as B LEFT JOIN BUILD_TOTAL_YEAR as C
                            ON A.SIG_CD=C.SIG_CD AND A.EMD_CD||A.LI_CD=C.BJD_CD
                            WHERE A.OGC_FID=B.OGC_FID GROUP BY A.OGC_FID; 
                    END TRANSACTION;
                """ #Join 결과 종합
                #A.OGC_FID1
            )
 
            use_year_sql = ("""
                    BEGIN TRANSACTION;
                    DROP TABLE IF EXISTS BULD_BUFFER;
                    CREATE TEMP TABLE BULD_BUFFER as
                        SELECT EMD_CD, buffer(GEOMETRY, 500) as GEOMETRY FROM {}
                        WHERE EMD_CD IN (SELECT SIG_CD||EMD_CD FROM {} WHERE USE_YEAR is NULL); 
                """.format(INTEGRATED_BSHAPE, BUILD_TABLE_NAME) #use_year 값이 없는 읍면동 경계 버퍼 생성
                +
                """
                    DROP TABLE IF EXISTS BULD_EMPTY_USE_YEAR;
                    CREATE TEMP TABLE BULD_EMPTY_USE_YEAR as
                        SELECT B.EMD_CD, substr(round(avg(A.USE_YEAR), 0), 1, 4) as USE_YEAR
                        FROM {} as A, BULD_BUFFER as B 
                        WHERE intersects(A.GEOMETRY, B.GEOMETRY)=1 AND A.USE_YEAR<>"" GROUP BY B.EMD_CD;
                """.format(BUILD_TABLE_NAME) #생성한 버퍼와 겹치는 구역의 사용승인년도 평균 값 구하기
                +
                """
                    UPDATE {} as A SET USE_YEAR = (
                        SELECT USE_YEAR FROM BULD_EMPTY_USE_YEAR as B WHERE B.EMD_CD=A.SIG_CD||A.EMD_CD ) 
                    WHERE USE_YEAR is NULL;
                    END TRANSACTION;
                """.format(BUILD_TABLE_NAME) #빈 사용승인년도 값 보완
            )
                                
            _DB.excScript(sql)
            self.inv.addGeometry(BUILD_ORIGIN_TABLE, BUILD_TABLE_NAME, "ogc_fid", "ogc_fid")
            _DB.excScript(use_year_sql)
     
        except Exception as e:
#             self.error.wrongFileMsg(e, "도로명 주소 기본도")
            raise Warning(str(e))
     