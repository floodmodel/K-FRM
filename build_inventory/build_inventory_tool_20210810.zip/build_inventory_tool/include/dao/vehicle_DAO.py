import codecs

from ..connectDB import SQLiteConnection
from ...lib.Util import *
from ..table_names import *
from .inventory_DAO import Integrated 
from ..error_list import ErrorList

class Vehicle:
    def __init__(self):
        global _DB
        _DB = SQLiteConnection()
        self.inv = Integrated()
        self.error = ErrorList()
        self.typeCol = None #타입별로 리스트에 넣음
        self.carCol = [ #타입 무관, 전체 컬럼 리스트
            "PAS1", "PAS2", "PAS3", "PAS4", "PAS5", "PAS6", "PAS7", "PAS8", "PAS9",                     
            "VAN1", "VAN2", "VAN3",
            "TRU1", "TRU2", "TRU3", "TRU4", "TRU5", "TRU6", "TRU7", "TRU8", "TRU9", "TRU10", "TRU11",
            "TYP1", "TYP2", "TYP3"
        ]
        
    def createVehicle(self): #결과 테이블
        try:
            sql = """
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        OGC_FID INTEGER PRIMARY KEY AUTOINCREMENT,
                        BASE_YEAR TEXT, 
                        ADM_CD TEXT, 
                        TOT_REG_CD TEXT, 
                        SIG_CD TEXT,
                        EMD_CD TEXT, 
                        L_ADMIN TEXT, 
                        {}_N REAL,
                        TYP1_N INTEGER,
                        TYP2_N INTEGER,
                        TYP3_N INTEGER
                    );
                """.format(VEHI_TABLE_NAME, VEHI_TABLE_NAME, "_N REAL, ".join(self.carCol[:23]))
            
            _DB.excScript(sql)
            self.selectVehiResult()
        except Exception as e:
            raise Warning(str(e))
    
    def createVehiKindNum(self, values):
        try:
            del values[0]
            colName, con = [], []
            self.typeCol = [[], [], []]
            
            for v in values:
                colName.append(v[3])
                con.append(v[4])

                listCnt = 0 if v[5].lower()=='typ1' else 1 if v[5].lower()=='typ2' else 2
                self.typeCol[listCnt].append(v[3])
                
            sql = """
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} ( {} REAL );
                """.format(VEHI_NUM_TABLE, VEHI_NUM_TABLE, " REAL, ".join(self.carCol[:23]))
            in_sql = "INSERT INTO {}({}) VALUES({});".format(VEHI_NUM_TABLE, ",".join(colName), ("?,"*23)[:-1])

            _DB.excScript(sql)
            _DB.excMany(in_sql, [tuple(con)])
        except Exception as e:
            self.error.wrongFileMsg(e, "차종비")
            raise Warning(str(e))
    
    def createVehiIndustry(self, values): #산업별 종사자 수 테이블
        try:
            sql = """
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        BASE_YEAR TEXT,
                        TOT_OA_CD TEXT,
                        ITEM TEXT,
                        VALUE NUMERIC
                    );
                """.format(VEHI_INDUSTRY_TABLE, VEHI_INDUSTRY_TABLE)
            
            _DB.excScript(sql)
            try : 
                with codecs.open(values, 'r', 'cp949') as f:
                    self.inv.insertData(VEHI_INDUSTRY_TABLE, f)    
            except UnicodeDecodeError:
                with codecs.open(values, 'r', 'utf-8') as f:
                    self.inv.insertData(VEHI_INDUSTRY_TABLE, f)    
                    
        except Exception as e:
            self.error.wrongFileMsg(e, "산업별 종사자 수")
            raise Warning(str(e))

    def createCarInfo(self, values): #차량 정보 테이블
        try:
            del values[0]
            sql = """
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        SIDO TEXT, 
                        SGG TEXT, 
                        NOTE TEXT,
                        TYP1 REAL,
                        TYP2 REAL,
                        TYP3 REAL
                    );
                """.format(VEHI_INFO_TABLE, VEHI_INFO_TABLE)
            in_sql = "INSERT INTO {} VALUES({});".format(VEHI_INFO_TABLE, ("?,"*6)[:-1])
                
            _DB.excScript(sql)
            _DB.excMany(in_sql, values)
        except Exception as e:
            self.error.wrongFileMsg(e, "자동차 등록 통계")
            raise Warning(str(e))
    
    def createTempCalcTable(self): #인구 계산 결과를 저장하는 테이블
        try:
            sql = ("""
                    BEGIN TRANSACTION;
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        TOT_OA_CD TEXT,
                        TP NUMERIC,
                        LP NUMERIC,
                        N NUMERIC
                    );
                """.format(VEHI_CALC_TABLE, VEHI_CALC_TABLE)
                +
                """
                    DROP INDEX IF EXISTS idx_car_age;
                    DROP INDEX IF EXISTS idx_car_industry;
                    CREATE INDEX idx_car_age ON {} (tot_oa_cd, item);
                    CREATE INDEX idx_car_industry ON {}(tot_oa_cd, item);
                """.format(INTEGRATED_AGE, VEHI_INDUSTRY_TABLE)
                +
                """
                    DROP TABLE IF EXISTS CAR_POPU;
                    CREATE TEMP TABLE CAR_POPU as
                        SELECT A.TOT_OA_CD, 
                            sum(CASE WHEN cast(substr(A.ITEM, 8, 3) as INTEGER)<=22 THEN A.VALUE END)/count(distinct B.ITEM) as TP,
                            sum(CASE WHEN B.VALUE<>"" THEN B.VALUE ELSE 0 END)/count(distinct A.ITEM) as LP
                        FROM {} as A, {} as B WHERE A.TOT_OA_CD=B.TOT_OA_CD GROUP BY A.TOT_OA_CD;
                """.format(INTEGRATED_AGE, VEHI_INDUSTRY_TABLE) #TP, LP 구하기
                +
                """
                    UPDATE CAR_POPU SET TP=0 WHERE TP is NULL;
                    UPDATE CAR_POPU SET LP=0 WHERE LP is NULL;
                """ # NUll값이면 계산 시 결과가 무조건 NULL로 나와 0으로 변경
                +
                """
                    DROP TABLE IF EXISTS CAR_TOTAL_POPU;
                    CREATE TEMP TABLE CAR_TOTAL_POPU as
                        SELECT substr(TOT_OA_CD, 1, 4) as TOT, sum(TP)+sum(LP) as N FROM CAR_POPU
                        GROUP BY substr(TOT_OA_CD, 1, 4);
                """ #총 합(총TP + 총LP) 인구 구하기
                +
                """
                    INSERT INTO {} 
                        SELECT A.TOT_OA_CD, A.TP, A.LP, B.N FROM CAR_POPU as A, CAR_TOTAL_POPU as B
                        WHERE substr(TOT_OA_CD, 1, 4)=B.TOT;
                """.format(VEHI_CALC_TABLE) 
                +
                """
                    UPDATE {} as A SET N = (TP+LP)*1.0/N;
                    END TRANSACTION;
                """.format(VEHI_CALC_TABLE)
            )
            
            _DB.excScript(sql)
        except Exception as e:
            raise Warning(str(e))    
    
    def selectVehiResult(self): #결과 도출
        try:   
            self.inv.addGeometry(VEHI_ORIGIN_TABLE, VEHI_TABLE_NAME, "tot_reg_cd", "tot_reg_cd")
            
            sql = (f"""
                BEGIN TRANSACTION;
                
                DROP INDEX IF EXISTS idx_car_popu;
                DROP INDEX IF EXISTS idx_car_bcode;
                CREATE INDEX idx_car_popu on {VEHI_CALC_TABLE}(tot_oa_cd);
                CREATE INDEX idx_car_bcode on {INTEGRATED_BCODE}(sido, sgg);
                
                DROP TABLE IF EXISTS CAR_VALUE;
                CREATE TEMP TABLE CAR_VALUE as
                    SELECT substr(A.CODE, 1, 8) as CODE, A.SIDO||' '||A.SGG as L_ADMIN,
                        B.{", B.".join(self.carCol[23:26])},
                        {", ".join([ ("B.TYP1*"+c+" as "+c) for c in self.carCol[0:9] ])},
                        {", ".join([ ("B.TYP2*"+c+" as "+c) for c in self.carCol[9:12] ])},
                        {", ".join([ ("B.TYP3*"+c+" as "+c) for c in self.carCol[12:23] ])}
                    FROM {INTEGRATED_BCODE} as A, {VEHI_INFO_TABLE} as B, {VEHI_NUM_TABLE} as C
                    WHERE A.SIDO=B.SIDO AND A.SGG LIKE B.SGG||'%';
                
                UPDATE CAR_VALUE SET 
                    TYP1 = {"+".join(self.typeCol[0])}, 
                    TYP2 = {"+".join(self.typeCol[1])}, 
                    TYP3 = {"+".join(self.typeCol[2])};
                
                DROP TABLE IF EXISTS CAR_BORDER;
                CREATE TEMP TABLE CAR_BORDER as
                    SELECT A.OGC_FID, A.BASE_YEAR, A.ADM_CD, A.TOT_REG_CD, B.EMD_CD, B.EMD_KOR_NM ,
                        st_area(st_intersection(buffer(A.geometry, 0), buffer(B.geometry, 0)))/st_area(buffer(A.geometry, 0)) as PROPORTION,
                        CastToMultipolygon(st_intersection(buffer(A.geometry, 0), buffer(B.geometry, 0))) as GEOMETRY
                    FROM {VEHI_ORIGIN_TABLE} as A, {INTEGRATED_BSHAPE} as B
                    WHERE intersects(B.GEOMETRY, A.GEOMETRY) AND
                        B.ROWID in (SELECT ROWID FROM SpatialIndex WHERE f_table_name='{INTEGRATED_BSHAPE}' AND search_frame=A.GEOMETRY);
                
                DROP TABLE IF EXISTS CAR_RESULT;     
                CREATE TEMP TABLE CAR_RESULT as
                    SELECT A.OGC_FID, A.BASE_YEAR, A.ADM_CD, A.TOT_REG_CD, 
                        substr(A.EMD_CD, 1, 5) as SIG_CD, substr(A.EMD_CD, 6, 3) as EMD_CD, 
                        B.L_ADMIN||' '||A.EMD_KOR_NM as L_ADMIN, B.{", B.".join(self.carCol)},
                        A.PROPORTION, A.GEOMETRY
                    FROM CAR_BORDER as A LEFT JOIN CAR_VALUE as B ON A.EMD_CD=B.CODE GROUP BY A.GEOMETRY;
                
                DROP INDEX IF EXISTS idx_car;
                CREATE INDEX idx_car on CAR_RESULT(tot_reg_cd);
                UPDATE CAR_RESULT as A SET ({", ".join(self.carCol)}) = 
                    (SELECT {", ".join(self.carCol)} FROM CAR_RESULT as B WHERE A.ADM_CD=B.ADM_CD 
                        GROUP BY ADM_CD HAVING max(TYP1)) 
                    WHERE L_ADMIN is NULL;
                    
                UPDATE CAR_RESULT as A SET ({", ".join(self.carCol)}) = 
                    (SELECT {"*B.N, ".join(self.carCol)}*B.N
                        FROM {VEHI_CALC_TABLE} as B WHERE A.TOT_REG_CD = B.TOT_OA_CD);
                
                UPDATE CAR_RESULT SET 
                    {", ".join([ (c+"=PROPORTION*"+c) for c in self.carCol ])};
                
                INSERT INTO {VEHI_TABLE_NAME} (BASE_YEAR, ADM_CD, TOT_REG_CD, 
                    SIG_CD, EMD_CD, L_ADMIN, {"_N, ".join(self.carCol)}_N, GEOMETRY)
                    SELECT BASE_YEAR, ADM_CD, TOT_REG_CD, SIG_CD, EMD_CD, L_ADMIN, 
                    round({", 5), round(".join(self.carCol[:23])}, 5), 
                    round({", 0), round(".join(self.carCol[23:])}, 0), GEOMETRY
                    FROM CAR_RESULT;
                
                END TRANSACTION;
            """)

            _DB.excScript(sql)
        except Exception as e:
            print(e)
            self.error.wrongFileMsg(e, "집계구 경계 전자지도")
            raise Warning(str(e))
      