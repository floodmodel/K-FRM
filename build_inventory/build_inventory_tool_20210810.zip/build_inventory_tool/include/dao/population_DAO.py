import codecs

from ..connectDB import SQLiteConnection
from ...lib.Util import *
from ..table_names import *
from .inventory_DAO import Integrated
from ..error_list import ErrorList

class Population:
    def __init__(self):
        global _DB
        _DB = SQLiteConnection()
        self.inv = Integrated()
        self.error = ErrorList()
        
    def createPopulation(self): #결과 테이블
        try:
            sql = """
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        OGC_FID INTEGER PRIMARY KEY AUTOINCREMENT,
                        BASE_YEAR TEXT,
                        ADM_CD TEXT,
                        TOT_REG_CD TEXT,
                        SIG_CD TEXT,
                        EMD_CD TEXT,
                        L_ADMIN TEXT,
                        TOT_POP_N REAL,
                        TOT_VUL_N REAL,
                        TOT_GEN_N REAL
                    );
                """.format(POPU_TABLE_NAME, POPU_TABLE_NAME)
            
            _DB.excScript(sql)
            self.selectPopuResult()
        except Exception as e:
            raise Warning(str(e))
    
    
    def selectPopuResult(self): #결과 도출
        try:
            self.inv.addGeometry(POPU_ORIGIN_TABLE, POPU_TABLE_NAME, "tot_reg_cd", "tot_reg_cd")
            
            sql = (f"""
                BEGIN TRANSACTION;
                
                DROP INDEX IF EXISTS idx_popu_age;
                CREATE INDEX idx_popu_age ON {INTEGRATED_AGE}(tot_oa_cd);
                
                DROP TABLE IF EXISTS POPU_CALC;
                CREATE TEMP TABLE POPU_CALC as 
                    SELECT BASE_YEAR, ADM_CD, TOT_REG_CD, 
                        (SELECT sum(VALUE) FROM {INTEGRATED_AGE} as B
                            WHERE A.TOT_REG_CD = B.TOT_OA_CD 
                                AND cast(substr(ITEM, 8, 3) as INTEGER)<=22 GROUP BY TOT_OA_CD) as TOT_POP, 
                        (SELECT sum(VALUE) FROM {INTEGRATED_AGE} as B 
                            WHERE A.TOT_REG_CD = B.TOT_OA_CD 
                                AND (ITEM="in_age_001" OR cast(substr(ITEM, 8, 3) as INTEGER) BETWEEN 14 AND 22) GROUP BY TOT_OA_CD) as VUL_POP,
                        0 as GEN_POP, A.GEOMETRY 
                    from {POPU_ORIGIN_TABLE} as A;
                
                UPDATE POPU_CALC SET TOT_POP=0 WHERE TOT_POP is null;
                UPDATE POPU_CALC SET VUL_POP=0 WHERE VUL_POP is null;
                UPDATE POPU_CALC SET GEN_POP=TOT_POP-VUL_POP;
                
                DROP INDEX IF EXISTS idx_integrated_bcode;
                CREATE INDEX idx_integrated_bcode ON {INTEGRATED_BCODE}(CODE);
                
                DROP TABLE IF EXISTS POPU_BORDER;
                CREATE TABLE POPU_BORDER as 
                    SELECT substr(A.EMD_CD, 1, 5) as SIG_CD, substr(A.EMD_CD, 6, 3) as EMD_CD,
                        B.SIDO||' '||B.SGG||' '||A.EMD_KOR_NM as L_ADMIN, A.GEOMETRY
                    FROM {INTEGRATED_BSHAPE} as A, {INTEGRATED_BCODE} as B WHERE substr(B.CODE, 1, 8)=A.EMD_CD GROUP BY A.OGC_FID;
                """
            )
            _DB.excScript(sql)
            self.inv.recoverGeometry(INTEGRATED_BSHAPE, 'POPU_BORDER') #공간 매핑을 위한 spatial_index 생성
            
            #공간 매핑을 진행할 때 geometry 값이 유효하지 않은 경우, intersects에서 결과 값은 정상으로 보이지만 
            #intersection에서는 결과 값이 null로 나옴. 이 오류를 해결해 주기 위해 buffer(geometry, 0)를 사용.
            sql = (f"""
                DROP TABLE IF EXISTS POPU_RESULT;
                CREATE TEMP TABLE POPU_RESULT as
                    SELECT A.BASE_YEAR, A.ADM_CD, A.TOT_REG_CD,
                        B.SIG_CD, B.EMD_CD, B.L_ADMIN, A.TOT_POP, A.VUL_POP, A.GEN_POP,
                        st_area(st_intersection(buffer(A.GEOMETRY, 0), buffer(B.GEOMETRY, 0)))/st_area(buffer(A.GEOMETRY, 0)) as PROPORTION,
                        CastToMultipolygon(st_intersection(buffer(A.GEOMETRY, 0), buffer(B.GEOMETRY, 0))) as GEOMETRY
                    FROM POPU_CALC as A, POPU_BORDER as B
                    WHERE intersects(A.GEOMETRY, B.GEOMETRY) AND 
                        B.ROWID in (SELECT rowid FROM SpatialIndex WHERE f_table_name='POPU_BORDER' AND search_frame=A.GEOMETRY);
                        
                UPDATE POPU_RESULT SET TOT_POP=TOT_POP*PROPORTION, VUL_POP=VUL_POP*PROPORTION, GEN_POP=GEN_POP*PROPORTION;
                
                INSERT INTO {POPU_TABLE_NAME} (BASE_YEAR, ADM_CD, TOT_REG_CD, SIG_CD, EMD_CD, L_ADMIN, TOT_POP_N, TOT_VUL_N, TOT_GEN_N, GEOMETRY)
                    SELECT BASE_YEAR, ADM_CD, TOT_REG_CD, SIG_CD, EMD_CD, L_ADMIN, TOT_POP, VUL_POP, GEN_POP, GEOMETRY
                        FROM POPU_RESULT;
                """
            )
            _DB.excScript(sql)
            
        except Exception as e:
            self.error.wrongFileMsg(e, "집계구 경계 전자지도")
            raise Warning(str(e))
        
