from ..connectDB import SQLiteConnection
from ...lib.Util import *
from ..table_names import *
from ..error_list import ErrorList
from .inventory_DAO import Integrated

class FarmLand:
    def __init__(self):
        global _DB, TYPE_ERROR
        _DB = SQLiteConnection()
        self.inv = Integrated()        
        self.error = ErrorList()
       
    def createFarmLand(self): #결과 테이블
        try:
            sql = """
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        ID TEXT,
                        LAND_CODE TEXT,
                        AGR_AREA REAL,
                        SIG_CD TEXT,
                        EMD_CD TEXT,
                        L_ADMIN TEXT,
                        PAD_A REAL,
                        FRU_A REAL,
                        GRE_A REAL,
                        GIN_A REAL,
                        UNF_A REAL,
                        UPL_SES_A REAL,
                        UPL_WAM_A REAL,
                        UPL_RAD_A REAL,
                        UPL_CAB_A REAL,
                        UPL_COR_A REAL,
                        UPL_SOY_A REAL,
                        UPL_SWP_A REAL
                    );
                """.format(FARM_TABLE_NAME, FARM_TABLE_NAME)
                
            _DB.excScript(sql)
            self.selectFarmResult()
        except Exception as e:
            raise Warning(str(e))
    
    def createFarmRefer(self, values): #농작물 비율 테이블 
        try:
            del values[0]
            sql = """
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        SIDO TEXT PRIMARY KEY NOT NULL, 
                        UPL_SES REAL,
                        UPL_WAM REAL,
                        UPL_RAD REAL,
                        UPL_CAB REAL,
                        UPL_COR REAL,
                        UPL_SOY REAL,
                        UPL_SWP REAL
                    );
                 """.format(FARM_REFER_TABLE, FARM_REFER_TABLE)
            in_sql = "INSERT INTO {} VALUES({});".format(FARM_REFER_TABLE, ("?,"*8)[:-1])
            
            _DB.excScript(sql)
            _DB.excMany(in_sql, values)

        except Exception as e:
            self.error.wrongFileMsg(e, "밭 재배 현황비")
            raise Warning(str(e))
    
    def createTempTable(self): #농작물 비율과 지역 매칭하는 임시테이블
        try:
            #농작물 비율에 명시되지 않은 지역은 인근 지역 값으로 사용
            sql = """
                DROP TABLE IF EXISTS FARM_TEMP;
                CREATE TEMP TABLE FARM_TEMP as 
                    SELECT distinct substr(A.'CODE', 1, 2) as CODE, B.* FROM '{}' as A, '{}' as B 
                        WHERE CASE WHEN A.'SIDO'="서울특별시" or A.'SIDO'="인천광역시" THEN "경기도"=B.'SIDO' 
                            WHEN A.'SIDO'="세종특별자치시" or A.'SIDO'="대전광역시" THEN "충청남도"=B.'SIDO'
                            WHEN A.'SIDO'="부산광역시" or A.'SIDO'="울산광역시" THEN "경상남도"=B.'SIDO'
                            WHEN A.'SIDO'="대구광역시" THEN "경상북도"=B.'SIDO'
                            WHEN A.'SIDO'="광주광역시" THEN "전라남도"=B.'SIDO'
                            WHEN A.'SIDO'="제주특별자치도" THEN "제주도"=B.'SIDO'
                            ELSE A.'SIDO'=B.'SIDO' END;
            """.format(INTEGRATED_BCODE, FARM_REFER_TABLE)
            _DB.excScript(sql)
        except Exception as e:
            raise Warning(str(e))
        
        
    def selectFarmResult(self): #결과 도출
        try:   
            self.inv.addGeometry(FARM_ORIGIN_TABLE, FARM_TABLE_NAME, "ID", "ID")

            calcValue = []
            farmNames = ["UPL_SES", "UPL_WAM", "UPL_RAD", "UPL_CAB", "UPL_COR", "UPL_SOY", "UPL_SWP"]
            
            for name in farmNames:
                calcValue.append(f"A.'AGR_AREA'*B.'{name}'*0.01") #작물 값
#             calcValue.append("+".join(calcValue)) #sum 값

            selectValue = """
                            A.'ID', A.'LAND_CODE', A.'AGR_AREA', A.'SIG_CD', A.'EMD_CD', A.'L_ADMIN',
                            CASE WHEN A.'LAND_CODE'="논" THEN A.'AGR_AREA' ELSE 0 END,
                            CASE WHEN A.'LAND_CODE'="과수" THEN A.'AGR_AREA' ELSE 0 END,
                            CASE WHEN A.'LAND_CODE'="시설" THEN A.'AGR_AREA' ELSE 0 END,
                            CASE WHEN A.'LAND_CODE'="인삼" THEN A.'AGR_AREA' ELSE 0 END,
                            CASE WHEN A.'LAND_CODE'="비경지" THEN A.'AGR_AREA' ELSE 0 END,
                            CASE WHEN A.'LAND_CODE'='밭' THEN
                        """
            selectValue+=" ELSE 0 END, CASE WHEN A.'LAND_CODE'='밭' THEN ".join(calcValue)+" ELSE 0 END, A.'GEOMETRY'"
            
            sql = (
                f"""
                BEGIN TRANSACTION;
                
                DROP TABLE IF EXISTS FARM_INTERSECTION;
                CREATE TEMP TABLE FARM_INTERSECTION as
                    SELECT A.'ID', A.'LAND_CODE', 0 as AGR_AREA, 
                        substr(A.'PNU', 1, 5) as SIG_CD, substr(A.'PNU', 6, 3) as EMD_CD,
                        substr(A.'PNU', 1, 10) as PNU10, '' as L_ADMIN,
                        CastToMultipolygon(st_intersection(buffer(A.GEOMETRY, 0), buffer(B.GEOMETRY, 0))) as GEOMETRY
                    FROM '{FARM_ORIGIN_TABLE}' as A, '{INTEGRATED_BSHAPE}' as B
                    WHERE intersects(A.GEOMETRY, B.GEOMETRY) AND 
                        B.ROWID in (SELECT rowid FROM SpatialIndex WHERE f_table_name='{INTEGRATED_BSHAPE}' AND search_frame=A.GEOMETRY);
                
                UPDATE FARM_INTERSECTION SET AGR_AREA = area(GEOMETRY);
                
                DROP INDEX IF EXISTS idx_farm_code;
                CREATE INDEX idx_farm_code ON INTEGRATED_BCODE(CODE);
                UPDATE FARM_INTERSECTION as A SET L_ADMIN = (
                    SELECT B.SIDO||' '||B.SGG||' '||B.EMD||' '||B.DL FROM {INTEGRATED_BCODE} as B WHERE A.PNU10=B.CODE);
                """
                #법정동 SHAPE와 공간 매칭 
                #원본 SHAPE에서 토지정보(LAND_CODE)가 비경지가 아닌 값만 추출
                #법정동 주소 정보 생성
                +
                """       
                    INSERT INTO {}
                    SELECT {} FROM '{}' as A, FARM_TEMP as B
                        WHERE B.'CODE'=substr(A.'SIG_CD', 1, 2);
                    
                    END TRANSACTION;
                """.format(FARM_TABLE_NAME, selectValue, 'FARM_INTERSECTION')      
            )
            
            _DB.excScript(sql)
#             self.inv.addGeometry(FARM_ORIGIN_TABLE, FARM_TABLE_NAME, "ID", "ID")
            
        except Exception as e:
            print(e)
            self.error.wrongFileMsg(e, "스마트 팜 맵")
            raise Warning(str(e))
            