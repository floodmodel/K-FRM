# -*- coding: utf-8 -*-
import os
import sys
from PyQt5.QtWidgets import *
from qgis.core import QgsApplication
from winreg import *
from .File_Class import *
from subprocess import call, Popen

# 메시지 박스 타이틀 일괄 적용 하기
# 미리 한번 호출해서 값 셋팅
def MsTitle(name, msgParent=None):
    global parent, title
    parent = msgParent
    title = name

def MsInfo(mess):
    QMessageBox.information(parent, title, str(mess)) 

def MsError(mess):
    QMessageBox.warning(parent, title, str(mess))

# 파일 다이얼 로그는 각자 만들어 쓰는게 편할지도... 임시로 만들어 둠    
def OpenFileDialog(txtbox, filetype):
    fname = QFileDialog.getOpenFileName(None, 'Open file-' + title ,'',filetype)
    txtbox.setText(str(fname[0]))

def OpenFilesDialog(filetype):
    fnames = QFileDialog.getOpenFileNames(None, 'Open file-' + title ,'',filetype)
    return fnames

def SaveFileDialog(txtbox, filetype):
    fname = QFileDialog.getSaveFileName(None, "Save file-"+ title, '', filetype)
    txtbox.setText(str(fname[0]))

def folderDialog(txtbox, kind):
    fpath = QFileDialog.getExistingDirectory(None,  kind+" folder-"+ title, '', QFileDialog.ShowDirsOnly|QFileDialog.DontResolveSymlinks)
    txtbox.setText(fpath)

# 레지스트리에서 QGIS 3.6 install 경로 받아 오기
def GetQGIS_Path():
    return QgsApplication.instance().applicationDirPath()+'/..'

def callExecute(arg):
    result = Popen(arg, shell=True)
    return result.communicate()
# 