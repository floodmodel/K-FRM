
# 2019-04-11 박: 동희가 작성 
style_css = ("""

    QDockWidget::title
    {
        background: rgb(200, 200, 200);
        text-align: left;
        padding-left: 30px;
    }
    QDockWidget::title:hover
    {
        background: darkgray;
    }
""")
