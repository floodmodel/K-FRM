import codecs

from ..connectDB import SQLiteConnection
from ...lib.Util import *
from ..table_names import *
from .inventory_DAO import Integrated 
from ..error_list import wrongFileMsg

class Vehicle:
    def __init__(self):
        global _DB
        _DB = SQLiteConnection()
        self.inv = Integrated()
        
    def createVehicle(self): #결과 테이블
        try:
            sql = """
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        OGC_FID INTEGER PRIMARY KEY AUTOINCREMENT,
                        BASE_YEAR TEXT, 
                        ADM_CD TEXT, 
                        TOT_REG_CD TEXT, 
                        SIG_CD TEXT,
                        EMD_CD TEXT, 
                        L_ADMIN TEXT, 
                        T1_N REAL,
                        T2_N REAL,
                        T3_N REAL,
                        T1_C REAL,
                        T2_C REAL,
                        T3_C REAL 
                    );
                """.format(VEHI_TABLE_NAME, VEHI_TABLE_NAME)
            
            _DB.excScript(sql)
            self.selectVehiResult()
        except Exception as e:
            raise Warning(str(e))
    
    def createVehiIndustry(self, values): #산업별 종사자 수 테이블
        try:
            sql = """
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        BASE_YEAR TEXT,
                        TOT_OA_CD TEXT,
                        ITEM TEXT,
                        VALUE NUMERIC
                    );
                """.format(VEHI_INDUSTRY_TABLE, VEHI_INDUSTRY_TABLE)
            
            _DB.excScript(sql)
            try : 
                with codecs.open(values, 'r', 'cp949') as f:
                    self.inv.insertData(VEHI_INDUSTRY_TABLE, f)    
            except UnicodeDecodeError:
                with codecs.open(values, 'r', 'utf-8') as f:
                    self.inv.insertData(VEHI_INDUSTRY_TABLE, f)    
                    
        except Exception as e:
            wrongFileMsg(e, "산업별 종사자 수")
            raise Warning(str(e))

    def createCarInfo(self, values): #차량 정보 테이블
        try:
            del values[0]
            sql = """
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        SIDO TEXT, 
                        SGG TEXT, 
                        NOTE TEXT,
                        T1_N REAL,
                        T2_N REAL,
                        T3_N REAL,
                        T1_C REAL,
                        T2_C REAL,
                        T3_C REAL
                    );
                """.format(VEHI_INFO_TABLE, VEHI_INFO_TABLE)
            in_sql = "INSERT INTO {} VALUES({});".format(VEHI_INFO_TABLE, ("?,"*9)[:-1])
                
            _DB.excScript(sql)
            _DB.excMany(in_sql, values)
        except Exception as e:
            wrongFileMsg(e, "차량 정보")
            raise Warning(str(e))
    
    def createTempCalcTable(self): #인구 계산 결과를 저장하는 테이블
        try:
            sql = ("""
                    BEGIN TRANSACTION;
                    DROP TABLE IF EXISTS {};
                    CREATE TABLE IF NOT EXISTS {} (
                        TOT_OA_CD TEXT,
                        TP NUMERIC,
                        LP NUMERIC,
                        N NUMERIC
                    );
                """.format(VEHI_CALC_TABLE, VEHI_CALC_TABLE)
                +
                """
                    DROP INDEX IF EXISTS idx_car_age;
                    DROP INDEX IF EXISTS idx_car_industry;
                    CREATE INDEX idx_car_age ON {} (tot_oa_cd, item);
                    CREATE INDEX idx_car_industry ON {}(tot_oa_cd, item);
                """.format(INTEGRATED_AGE, VEHI_INDUSTRY_TABLE)
                +
                """
                    DROP TABLE IF EXISTS CAR_POPU;
                    CREATE TEMP TABLE CAR_POPU as
                        SELECT A.TOT_OA_CD, 
                            sum(CASE WHEN cast(substr(A.ITEM, 8, 3) as INTEGER)<=22 THEN A.VALUE END)/count(distinct B.ITEM) as TP,
                            sum(CASE WHEN B.VALUE<>"" THEN B.VALUE ELSE 0 END)/count(distinct A.ITEM) as LP
                        FROM {} as A, {} as B WHERE A.TOT_OA_CD=B.TOT_OA_CD GROUP BY A.TOT_OA_CD;
                """.format(INTEGRATED_AGE, VEHI_INDUSTRY_TABLE) #TP, LP 구하기
                +
                """
                    UPDATE CAR_POPU SET TP=0 WHERE TP is NULL;
                    UPDATE CAR_POPU SET LP=0 WHERE LP is NULL;
                """ # NUll값이면 계산 시 결과가 무조건 NULL로 나와 0으로 변경
                +
                """
                    DROP TABLE IF EXISTS CAR_TOTAL_POPU;
                    CREATE TEMP TABLE CAR_TOTAL_POPU as
                        SELECT substr(TOT_OA_CD, 1, 4) as TOT, sum(TP)+sum(LP) as N FROM CAR_POPU
                        GROUP BY substr(TOT_OA_CD, 1, 4);
                """ #총 합(총TP + 총LP) 인구 구하기
                +
                """
                    INSERT INTO {} 
                        SELECT A.TOT_OA_CD, A.TP, A.LP, B.N FROM CAR_POPU as A, CAR_TOTAL_POPU as B
                        WHERE substr(TOT_OA_CD, 1, 4)=B.TOT;
                """.format(VEHI_CALC_TABLE) 
                +
                """
                    UPDATE {} as A SET N = (TP+LP)*1.0/N;
                    END TRANSACTION;
                """.format(VEHI_CALC_TABLE)
            )
            
            _DB.excScript(sql)
        except Exception as e:
            raise Warning(str(e))    
    
    def selectVehiResult(self): #결과 도출
        try:   
            self.inv.addGeometry(VEHI_ORIGIN_TABLE, VEHI_TABLE_NAME, "tot_reg_cd", "tot_reg_cd")
            
            sql = (f"""
                BEGIN TRANSACTION;
                
                DROP INDEX IF EXISTS idx_car_popu;
                DROP INDEX IF EXISTS idx_car_bcode;
                CREATE INDEX idx_car_popu on {VEHI_CALC_TABLE}(tot_oa_cd);
                CREATE INDEX idx_car_bcode on {INTEGRATED_BCODE}(sido, sgg);
                
                DROP TABLE IF EXISTS CAR_VALUE;
                CREATE TEMP TABLE CAR_VALUE as
                    SELECT substr(A.CODE, 1, 8) as CODE, A.SIDO||' '||A.SGG as L_ADMIN,
                        B.T1_N, B.T2_N, B.T3_N, B.T1_C, B.T2_C, B.T3_C
                    FROM {INTEGRATED_BCODE} as A, {VEHI_INFO_TABLE} as B
                    WHERE A.SIDO=B.SIDO AND A.SGG LIKE B.SGG||'%';
                
                DROP TABLE IF EXISTS CAR_BORDER;
                CREATE TABLE CAR_BORDER as
                    SELECT A.OGC_FID, A.BASE_YEAR, A.ADM_CD, A.TOT_REG_CD, B.EMD_CD, B.EMD_KOR_NM ,
                        st_area(st_intersection(buffer(A.geometry, 0), buffer(B.geometry, 0)))/st_area(buffer(A.geometry, 0)) as PROPORTION,
                        CastToMultipolygon(st_intersection(buffer(A.geometry, 0), buffer(B.geometry, 0))) as GEOMETRY
                    FROM {VEHI_ORIGIN_TABLE} as A, {INTEGRATED_BSHAPE} as B
                    WHERE intersects(B.GEOMETRY, A.GEOMETRY) AND
                        B.ROWID in (SELECT ROWID FROM SpatialIndex WHERE f_table_name='{INTEGRATED_BSHAPE}' AND search_frame=A.GEOMETRY);
                
                DROP TABLE IF EXISTS CAR_RESULT;     
                CREATE TEMP TABLE CAR_RESULT as
                    SELECT A.OGC_FID, A.BASE_YEAR, A.ADM_CD, A.TOT_REG_CD, 
                        substr(A.EMD_CD, 1, 5) as SIG_CD, substr(A.EMD_CD, 6, 3) as EMD_CD, 
                        B.L_ADMIN||' '||A.EMD_KOR_NM as L_ADMIN, B.T1_N, B.T2_N, B.T3_N, B.T1_C, B.T2_C, B.T3_C,
                        A.PROPORTION, A.GEOMETRY
                    FROM CAR_BORDER as A LEFT JOIN CAR_VALUE as B ON A.EMD_CD=B.CODE GROUP BY A.GEOMETRY;
                
                DROP INDEX IF EXISTS idx_car;
                CREATE INDEX idx_car on CAR_RESULT(tot_reg_cd);
                UPDATE CAR_RESULT as A SET (T1_N, T2_N, T3_N, T1_C, T2_C, T3_C) = 
                    (SELECT T1_N, T2_N, T3_N, T1_C, T2_C, T3_C FROM CAR_RESULT as B WHERE A.ADM_CD=B.ADM_CD 
                        GROUP BY ADM_CD HAVING max(T1_N)) 
                    WHERE L_ADMIN is NULL;
                    
                UPDATE CAR_RESULT as A SET (T1_N, T2_N, T3_N, T1_C, T2_C, T3_C) = 
                    (SELECT A.T1_N*B.N, A.T2_N*B.N, A.T3_N*B.N, A.T1_C*B.N, A.T2_C*B.N, A.T3_C*B.N
                        FROM {VEHI_CALC_TABLE} as B WHERE A.TOT_REG_CD = B.TOT_OA_CD);
                
                UPDATE CAR_RESULT SET 
                    T1_N=T1_N*PROPORTION, T2_N=T2_N*PROPORTION, T3_N=T3_N*PROPORTION,
                    T1_C=T1_C*PROPORTION, T2_C=T2_C*PROPORTION, T3_C=T3_C*PROPORTION;
                
                INSERT INTO {VEHI_TABLE_NAME} (BASE_YEAR, ADM_CD, TOT_REG_CD, 
                    SIG_CD, EMD_CD, L_ADMIN, T1_N, T2_N, T3_N, T1_C, T2_C, T3_C, GEOMETRY)
                    SELECT BASE_YEAR, ADM_CD, TOT_REG_CD, 
                        SIG_CD, EMD_CD, L_ADMIN, T1_N, T2_N, T3_N, T1_C, T2_C, T3_C, GEOMETRY
                    FROM CAR_RESULT;
                    
                END TRANSACTION;
            """)
            
            _DB.excScript(sql)
        except Exception as e:
            wrongFileMsg(e, "집계구 경계 전자지도")
            raise Warning(str(e))
      