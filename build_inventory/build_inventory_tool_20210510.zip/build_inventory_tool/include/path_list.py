# -*- coding: utf-8 -*-
from ..lib.File_Class import *
from ..lib.Util import *

#--- 경로
LOCAL_PATH = GetScriptDirectory_Path()+"/.."        # 플러그인 경로
QGIS_PATH = GetQGIS_Path()                          # QGIS 설치 경로

OGR_PATH = QGIS_PATH+"/bin/ogr2ogr.exe"             # OGR2OGR 실행 프로그램 경로

DB_DLL_PATH = LOCAL_PATH+"/DB/mod_spatialite.dll"   # DB spatial dll 경로
EMPTY_DB = LOCAL_PATH+"/DB/EmptyDB.sqlite"          # 빈 DB 경로
DB_PATH = LOCAL_PATH+"/DB/SQLiteDB.sqlite"          # 사용하는 DB 경로

UI_SETTING_PATH = LOCAL_PATH+"/save_ui.ini"         # UI 설정 파일 경로