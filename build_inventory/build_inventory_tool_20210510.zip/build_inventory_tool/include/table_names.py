# -*- coding: utf-8 -*-

#-------------------- 농작물 -----------------------------------

#농작물 결과 내용 저장 테이블
FARM_TABLE_NAME = "INV_FARMLAND"

#참조 테이블 : 농작물 비율 정보 테이블
FARM_REFER_TABLE = "FARM_REFERRENCE"

#원본 데이터를 가진 테이블
FARM_ORIGIN_TABLE = "FARM_ORIGIN_TABLE"

#-------------------- 인구  -----------------------------------

#인구 결과 테이블
POPU_TABLE_NAME = "INV_POPULATION"

#원본 테이블 
POPU_ORIGIN_TABLE = "POPU_ORIGIN_TABLE"


#-------------------- 차량  -----------------------------------

#차량 결과 테이블
VEHI_TABLE_NAME = "INV_CAR"

#산업별 종사자 수 테이블
VEHI_INDUSTRY_TABLE = "CAR_INDUSTRY"

#차량 가치 테이블 
VEHI_INFO_TABLE = "CAR_INFO"

#계산 테이블
VEHI_CALC_TABLE = "CAR_CALC_TABLE"

#원본 테이블 
VEHI_ORIGIN_TABLE = "CAR_ORIGIN_TABLE"

#-------------------- 건물 -----------------------------------

#건물 결과 테이블
BUILD_TABLE_NAME = "INV_BUILDING"

#건물 용도 테이블
BUILD_PURPOSE_TABLE = "BUILD_PURPOSE"

#건물 구조 테이블
BUILD_STRUCTURE_TABLE = "BUILD_STRUCTURE"

#표제부 테이블
BUILD_TITLE_TABLE = "BUILD_TITLE"

#건물 용도, shape 테이블
BUILD_INFO_TABLE = "BUILD_INFO"

#원본 테이블 
BUILD_ORIGIN_TABLE = "BUILD_ORIGIN_TABLE"

#-------------------- 통합 -----------------------------------

#법정동 코드
INTEGRATED_BCODE = "INTEGRATED_BCODE"

#성 연령별 인구
INTEGRATED_AGE = "INTEGRATED_AGE"

#법정동 경계 전자지도
INTEGRATED_BSHAPE = "INTEGRATED_BORDER"

#-------------------- 에러 ------------------------------------

COUNT_ERROR = "incorrect number of bindings supplied"
COLUMN_ERROR = "no such column"
INDEX_ERROR = "index out of range"

