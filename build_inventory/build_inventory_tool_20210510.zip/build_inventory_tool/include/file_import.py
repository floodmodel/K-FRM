# -*- coding: utf-8 -*-
import xlrd, codecs

from ..lib.Util import *
from .path_list import *

#ogr2ogr.exe 프로그램을 사용하여 shape 파일을 DB에 적재함.
def shapeImport(shpPath, saveName, encoding="UTF-8"): 
    arg = ('"{}" -f SQLite -dsco SPATIALITE=YES "{}" "{}" -nlt PROMOTE_TO_MULTI -overwrite --config SHAPE_ENCODING {} -nln "{}"'
                       .format(OGR_PATH, DB_PATH, shpPath, encoding, saveName))

    return callExecute(arg)

#xlrd를 사용하여 엑셀 파일을 읽고 내용을 전달. DB에는 직접 넣어야 함.
#전달 방식은 각 행별로 리스트로 묶어 전달. -> [[1행], [2행]]
def excelRead(excelPath, sheetNumber=0):
    try:    
        workBook = xlrd.open_workbook(excelPath) #엑셀 파일
        workSheet = workBook.sheet_by_index(sheetNumber) #엑셀 시트
        
        values = []
        for i in range(workSheet.nrows):
            values.append(tuple(workSheet.row_values(i)))
            
        return values
    except Exception as e:
        raise Warning(e)

#파이썬 내장 함수를 사용하여 텍스트 파일을 읽고 내용을 전달. 역시 DB에는 직접 삽입.
#\n 로 줄을 나눈 후 ^ 문자로 다시 나눔
def txtRead(txtPath, separator="^"):
    try:
        f = open(txtPath)
        con = f.read().split("\n")
        
        values = []
        for c in con:
            values.append(c.split(separator))
        
        return values   
    except Exception as e:
        raise Warning(e)

#텍스트 파일에서 2번째 줄 내용을 읽어 반환     
def txtSomeRead(filePath):
    try : 
        with codecs.open(filePath, 'r', 'cp949') as f:
            f.readline()
            value = f.readline()
    except UnicodeDecodeError:
        with codecs.open(filePath, 'r', 'utf-8') as f:
            f.readline()
            value = f.readline()
    except Exception as e:
        raise Warning(e)    
    
    return value
    