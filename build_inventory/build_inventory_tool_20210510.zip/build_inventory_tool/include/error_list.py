# -*- coding: utf-8 -*-
from ..lib.File_Class import *
from .dao.inventory_DAO import Integrated
from .table_names import COUNT_ERROR, COLUMN_ERROR, INDEX_ERROR

inv = Integrated() 

#파일을 선택하는 곳에서 경로가 비어있거나, 존재하지 않는 경로일 경우 에러.
def filePathErrorConfirm(filePath, txt):
    if filePath.strip() == "" :
        raise Warning(f"{txt} 이/가 선택되지 않았습니다.")
    
    if not ChFile_Exists(filePath):
        raise Warning(f"{txt} 이/가 존재하지 않습니다.")
    
#DB에 파일이 존재하지 않거나 filePathErrorConfirm 함수와 같은 경우
def checkFileErrorConfirm(path, chk, txt, tableName):
    if chk.isChecked():
        if not inv.isTabled(tableName) or inv.countRow(tableName)[0][0]==0:
            raise Warning(f"저장된 {txt} 내용이 존재하지 않습니다. 파일을 입력해 주시길 바랍니다.")
        return False
    else:
        filePathErrorConfirm(path, txt)
        return True

#에러 메시지에서 특정 문자가 포함된 경우
def wrongFileMsg(errMsg, fileName):
    errMsg = str(errMsg).lower()
    if (COUNT_ERROR in errMsg) or (COLUMN_ERROR in errMsg) or (INDEX_ERROR in errMsg):
        raise Warning(f"입력하신 {fileName} 자료에 오류가 있습니다.")

#텍스트 문장에서 특정 단어가 포함되지 않은 경우
def txtNotInValue(someMsg, allMsg, fileName):
    if someMsg not in allMsg:
        raise Warning(f"입력하신 {fileName} 자료에 오류가 있습니다.")

#테이블에 특정 칼럼이 존재하지 않는 경우    
def isNotColumn(tableName, columns, fileName):
    try:
        inv.isColumns(tableName, columns)
    except Exception as e:
        if COLUMN_ERROR in str(e):
            raise Warning(f"입력하신 {fileName} 자료에 오류가 있습니다.")
        else:
            raise Warning(e)