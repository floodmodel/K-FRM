from ..db_connection import PostgreSQLConnection

class PgQuery:
    def __init__(self):
        self.pg = PostgreSQLConnection()

    
    #select
    def getGeometryInfo(self, tableName):
        sql = f"SELECT * FROM geometry_columns WHERE f_table_name='{tableName}'"
        #return : catalog, schema, tableName, geomName, coord, srid, geomType
        return self.pg.excValue(sql)[0]
    
    def getProj4OrSrid(self, type, ref):
        #ref = srid, auth_name, proj, srtext
        if type==1: #get srid
            content = ref[2].strip().replace("  ", " ")
            target, where = "srid", f"proj4text ilike '%{content}%'"
        else: #get proj4
            content = ref[0]
            target, where = "proj4text", f"srid = {content}"
            
        sql = f"SELECT {target} from spatial_ref_sys where {where};"
        ret = self.pg.excValue(sql)
        
        if not ret:
            try:
                inSql = f"INSERT INTO spatial_ref_sys VALUES({ref[0]}, '{ref[1].upper()}', {ref[0]}, '{ref[3]}', '{ref[2]}');"
                print(inSql)
                self.pg.excNone(inSql)
            except Exception as e:
                raise Warning("It is not the specified coordinate system. Please change to a different coordinate system.")
            
        return self.pg.excValue(sql)[0][0]
    
    def getTableHeader(self, tableName):
        sql = f"SELECT column_name FROM information_schema.columns WHERE table_name='{tableName}';"
        result = self.pg.excValue(sql)
        header = [h[0] for h in result]
        return header
    
    def getTableYearList(self):
#         sql = f"SELECT distinct tablename FROM pg_tables WHERE schemaname='public' and tablename like '{tableName}%';"
        sql = f"select years from inventory_years"
        ret = self.pg.excValue(sql)
        years = [str(y[0]) for y in ret]
        return years
        
    def getTableAllContents(self, tableName, columns="*", order=""):
        sql = f'SELECT {columns} FROM "{tableName}" {order};'
        return self.pg.excValue(sql)
    
    def getAreaSql(self, tableName, area):
        areaList = area.split(", ")
        areaSql = ""
        for ar in areaList:
            areaSql += f"l_admin like '{ar}%' or "
            
        sql = f'SELECT distinct sig_cd FROM "{tableName}" WHERE {areaSql[:-4]};'
        codeList = self.pg.excValue(sql)
        codeSql = ""
        for code in codeList:
            codeSql += f"sig_cd like '{code[0]}%' or "
            
        sql = f'SELECT * FROM "{tableName}" WHERE {codeSql[:-4]};'          
        return sql

    def getIntersectAreaName(self, tableName, sqliteGeom, sqliteRef):
        postGeomInfo = self.getGeometryInfo(tableName)
        postgisGeom = postGeomInfo[3]
        postgisSrid = postGeomInfo[5]
        sqliteSrid = self.getProj4OrSrid(1, sqliteRef)

        sql = f""" SELECT distinct split_part(l_admin, ' ', 1)||' '||split_part(l_admin, ' ', 2) as area 
                    FROM "{tableName}" WHERE 
                    st_intersects(
                        ST_Buffer(ST_Transform(ST_SetSRID(ST_GeomFromText('{sqliteGeom}'), {sqliteSrid}), {postgisSrid}), 0), 
                        ST_Transform(ST_SetSRID({postgisGeom}, {postgisSrid}), {postgisSrid})
                    ) ORDER BY area asc;"""

        ret = self.pg.excValue(sql)
        area = [a[0] for a in ret if a[0]] 
        return ", ".join(area)
    
    def getPopuUnitCosts(self, year):
        sql = f'SELECT * FROM "population_unit_cost" WHERE year={year}'
        return self.pg.excValue(sql)
    
    def getGridContent(self, wkt):
        sql = f"""
            SELECT gid, value, ST_AsText(geometry) as wkt 
            FROM base_grid_500m 
            WHERE ST_Intersects(geometry, ST_GeomFromText('{wkt}', 5179));
        """
        ret = self.pg.excValue(sql)
        return ret