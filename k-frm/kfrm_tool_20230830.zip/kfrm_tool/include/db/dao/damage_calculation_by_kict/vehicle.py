from kfrm_tool.include.setting import name_list


def vehicle_damage_calculation(
    floodTable,
    invenTable,
    invenGeom,
    floodGeom,
    geomType,
    depthColumn,
    resultTable,
):
    sql = ""

    # 테이블 초기화
    clear_table = f"""
      DROP TABLE IF EXISTS '{resultTable}';
    """
    sql += clear_table

    # 테이블 생성
    # 테이블 속성과 값을 설정하는 부분으로, 수정할 일이 거의 없을 걸로 예상
    create_table = f"""
      CREATE TABLE '{resultTable}' as
        SELECT
          cast(A.ogc_fid as Integer) as ogc_fid,
          cast(B.'{depthColumn}' as Real) as depth,
          cast(area(A.geometry) as Real) as imm,
          cast(A.sig_cd as Text) as sig_cd,
          cast(A.emd_cd as Text) as emd_cd,
          cast(0 as Real) as t1_n_2,
          cast(0 as Real) as t2_n_2,
          cast(0 as Real) as t3_n_2,
          cast(0 as Real) as t1_n_3,
          cast(0 as Real) as t2_n_3,
          cast(0 as Real) as t3_n_3,
          cast(A.l_admin as Text) as l_admin,
          cast(A.t1_n as Real) as t1_n,
          cast(A.t2_n as Real) as t2_n,
          cast(A.t3_n as Real) as t3_n,
          cast(A.t1_n as Real) as t1_n_exps,
          cast(A.t2_n as Real) as t2_n_exps,
          cast(A.t3_n as Real) as t3_n_exps,
          cast(A.t1_c as Real) as t1_c_exps,
          cast(A.t2_c as Real) as t2_c_exps,
          cast(A.t3_c as Real) as t3_c_exps,
          cast(0 as Real) as t1_n_dmg,
          cast(0 as Real) as t2_n_dmg,
          cast(0 as Real) as t3_n_dmg,
          cast(0 as Real) as t1_c_dmg,
          cast(0 as Real) as t2_c_dmg,
          cast(0 as Real) as t3_c_dmg,
          CastTo{geomType}(
            intersection(
              buffer(
                A.'{invenGeom}',
                0
              ), 
              buffer(
                B.'{floodGeom}',
                0
              )
            )
          ) as '{invenGeom}'
        FROM 
          "{invenTable}" as A,
          "{floodTable}" as B
        WHERE 
          Intersects(
            B.'{floodGeom}',
            A.'{invenGeom}'
          ) AND
          A.rowid in (
            SELECT
              rowid
            FROM
              SpatialIndex
            WHERE
              f_table_name='{invenTable}'
              AND search_frame=B.'{floodGeom}'
          );
    """
    sql += create_table

    # 임시 테이블 생성
    create_temp_table = f"""
      DROP TABLE IF EXISTS 'vehicle_tn_sum';
      CREATE TEMP TABLE 'vehicle_tn_sum' as
        SELECT * FROM '{resultTable}' GROUP BY sig_cd, emd_cd, ogc_fid;
    """
    sql += create_temp_table

    # 테이블 업데이트

    # CASE문 생성
    # A는 resultTable 테이블, B는 name_list.V_VULFUNC 테이블
    case = [f"CASE WHEN A.depth={i} then B.'{i}' ELSE " for i in range(11)]
    case = "".join(case) + " B.'11' " + ("END " * 11)

    update_table = ""

    update_table += f"""
      UPDATE 
        '{resultTable}' as A 
      SET 
        (t1_n_2, t2_n_2, t3_n_2) = (
          SELECT 
            sum(B.t1_n), 
            sum(B.t2_n), 
            sum(B.t3_n) 
          FROM 
            'vehicle_tn_sum' as B 
          WHERE 
            A.sig_cd=B.sig_cd 
          GROUP BY B.sig_cd
        );
      """

    update_table += f"""
      UPDATE 
        '{resultTable}' as A 
      SET 
        (t1_n_3, t2_n_3, t3_n_3) = (
          SELECT 
            sum(B.t1_n),
            sum(B.t2_n),
            sum(B.t3_n)
          FROM 
            'vehicle_tn_sum' as B 
          WHERE 
            A.sig_cd=B.sig_cd
            AND A.emd_cd=B.emd_cd 
          GROUP BY 
            B.sig_cd,
            B.emd_cd
        );
    """

    # 노출차량 대수 계산 => 침수구역면적 / 집계구 면적 * 유형별 차량대수
    # 노출차량 가치 계산 => 침수구역면적 / 집계구 면적 * 유형별 차량가치
    update_table += f"""
      UPDATE '{resultTable}' SET imm=area({invenGeom})/imm;

      UPDATE
        '{resultTable}' 
      SET
        (t1_n_exps, t2_n_exps, t3_n_exps, t1_c_exps, t2_c_exps, t3_c_exps) = 
        (t1_n_exps*imm, t2_n_exps*imm, t3_n_exps*imm, t1_c_exps*imm, t2_c_exps*imm, t3_c_exps*imm);
    """

    # 차량 피해 계산 => 유형별 차량가치 * 손상률
    update_table += f"""
      UPDATE 
        '{resultTable}' as A 
      SET 
        t1_c_dmg = (SELECT ({case})*A.t1_c_exps*10/1000
          FROM '{name_list.V_VULFUNC}' as B WHERE type="type 1"),
        t2_c_dmg = (SELECT ({case})*A.t2_c_exps*10/1000 
          FROM '{name_list.V_VULFUNC}' as B WHERE type="type 2"),
        t3_c_dmg = (SELECT ({case})*A.t3_c_exps*10/1000
          FROM '{name_list.V_VULFUNC}' as B WHERE type="type 3");
    """

    # 피해차량 대수 계산 => if 손상률 > 0 then 노출차량대수 else 0
    update_table += f"""
      UPDATE '{resultTable}' SET 
        t1_n_dmg = (CASE WHEN t1_c_dmg>0 THEN t1_n_exps ELSE 0 END),
        t2_n_dmg = (CASE WHEN t2_c_dmg>0 THEN t2_n_exps ELSE 0 END),
        t3_n_dmg = (CASE WHEN t3_c_dmg>0 THEN t3_n_exps ELSE 0 END);
    """
    sql += update_table

    return sql
