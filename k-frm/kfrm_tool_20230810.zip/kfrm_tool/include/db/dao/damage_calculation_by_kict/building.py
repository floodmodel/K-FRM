from kfrm_tool.include.setting import name_list


def building_damage_calculation(
    invenHeader,
    depthColumn,
    invenGeom,
    invenTable,
    floodTable,
    floodGeom,
    resultTable,
) -> str:
    # depth에 따른 취약성 계수
    outVul = "CASE "
    for i in range(1, 12):
        a = round((i - 1) * 0.3, 1)
        b = round(i * 0.3, 1)
        outVul += f"WHEN {a}<=A.inner_depth AND A.inner_depth<{b} THEN B.'{i}' "
    outVul += "ELSE B.'0' END"
    innerValue = outVul.replace("B.", "C.")

    sql = ""

    # 중복된 테이블이 있으면 삭제
    clear_table = f"""
      DROP TABLE IF EXISTS building_result;
      DROP TABLE IF EXISTS "{resultTable}";
    """
    sql += clear_table

    # building_result 테이블 생성
    create_table = f"""
      CREATE TEMP TABLE building_result as
        SELECT
          A.{", A.".join(invenHeader[:-1])},
          B."{depthColumn}" as depth,
          CASE WHEN B."{depthColumn}"-C.height<=0 THEN 0 ELSE B."{depthColumn}"-C.height END as inner_depth,
          CASE WHEN B."{depthColumn}"-C.height<=0 THEN 0 ELSE 1 END as dmg_flag,
          0 as f_dmg_str,
          0 as f_dmg_cont,
          0 as dmg_str,
          0 as dmg_cont,
          0 as dmg_sum,
          A.{invenGeom}
        FROM
          "{invenTable}" as A,
          "{floodTable}" as B,
          "{name_list.B_ENTRACE}" as C
        WHERE
          A.bdtyp=C.occupancy
          AND Intersects(B.'{floodGeom}', A.'{invenGeom}')
          AND A.rowid in (
            SELECT rowid
            FROM SpatialIndex
            WHERE
              f_table_name='{invenTable}'
              AND search_frame=B.'{floodGeom}'
          );
    """
    sql += create_table

    # 구조물 피해 f_dmg_str 계산 => 구조물 가치 * 손상률 / 100
    # 내용물 피해 f_dmg_cont 계산 => 내용물 가치 * 손상률 / 100
    update_f_dmg_str_cont = f"""
      UPDATE building_result as A
      SET (f_dmg_str, f_dmg_cont)=(
        SELECT
          CASE WHEN A.dmg_flag=0 THEN 0 ElSE {outVul} END,
          CASE WHEN A.dmg_flag=0 THEN 0 ElSE {innerValue} END
        FROM
          {name_list.B_SDAMAGE} as B,
          {name_list.B_IDAMAGE} as C
        WHERE
          A.bdtyp=B.occupancy
          AND A.bdtyp=C.occupancy
          AND (
            CASE
              WHEN A.bdtyp="단독주택" THEN A.bdstr=B.description
              ELSE (B.description is NULL or B.description="")
            END
          )
        );
    """
    sql += update_f_dmg_str_cont

    # dmg_str, dmg_cont, dmg_sum 계산
    update_dmg_str_cont_sum = f"""
      UPDATE building_result as A
      SET
        dmg_str = ifNull(str_value*(f_dmg_str/100), 0),
        dmg_cont = ifNull(cont_value*(f_dmg_cont/100), 0),
        dmg_sum = ifNull(str_value*(f_dmg_str/100), 0) + ifNull( cont_value*(f_dmg_cont/100), 0);
    """
    sql += update_dmg_str_cont_sum

    # 최종 결과 테이블 생성
    create_result_table = f"""
      CREATE TABLE "{resultTable}" as
        SELECT
          cast(ogc_fid as Integer) as ogc_fid,
          cast(sig_cd as Text) as sig_cd,
          cast(emd_cd as Text) as emd_cd,
          cast(l_admin as Text) as l_admin,
          cast(bdtyp as Text) as bdtyp,
          cast(str_value as Real) as str_value,
          cast(cont_value as Real) as cont_value,
          cast(dmg_flag as Integer) as dmg_flag,
          cast(f_dmg_str as Real) as f_dmg_str,
          cast(f_dmg_cont as Real) as f_dmg_cont,
          cast(dmg_str as Real) as dmg_str,
          cast(dmg_cont as Real) as dmg_cont,
          cast(dmg_sum as Real) as dmg_sum,
          {invenGeom}
        FROM building_result;
    """
    sql += create_result_table

    return sql
