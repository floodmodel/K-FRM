from kfrm_tool.include.setting import name_list


def agriculture_damage_calculation(
    floodTable,
    invenTable,
    invenGeom,
    floodGeom,
    geomType,
    depthColumn,
    tempResult,
    invenOriHeader,
    resultTable,
):
    sql = ""

    cdmgList, fdmgList, crpArList, prdLsList, prfLsList, updtList = [
        [] for _ in range(6)
    ]
    cReTblName, fReTblName = name_list.A_CDAMAGE + "_re", name_list.A_FDAMAGE + "_re"

    # 농작물 및 농경지 손상 함수 생성
    for i in range(12):
        s = f'SELECT farmland, crops, {i} as depth, "{i}" as value FROM '
        cdmgList.append(s + name_list.A_CDAMAGE)
        fdmgList.append(s.replace(", crops", "") + name_list.A_FDAMAGE)

    dicKeys = []
    for i, k in enumerate(name_list.CROP_KINDS):
        if k == "fru":
            continue
        dicKeys.append(k)
        farm, crop = name_list.CROP_KINDS[k].split(", ")
        areaColumn = (
            f"A.intersect_area"
            if 5 > i
            else f"((A.intersect_area/A.agr_area)*A.upl_{k}_a)"
        )
        crpArList.append(f"cast({areaColumn} as Real) as {k}_crp_ar")
        lstr = f"""cast(CASE WHEN A.land_code='{farm}' THEN 
                        ifnull(A.intersect_area/A.agr_area*A.{k}_prdc/1000*(
                            SELECT value FROM {cReTblName} as B 
                            WHERE A.depth=B.depth AND A.land_code=B.farmland AND B.crops='{crop}'
                        )/100, 0) 
                    ELSE 0 END as Real) as {k}_prd_ls \n"""
        prdLsList.append(lstr)
        prfLsList.append(lstr.replace("prdc", "prft").replace("prd", "prf"))
        updtList.append(f"CASE WHEN {k}_prd_ls>0 THEN {k}_crp_ar ELSE 0 END")

    # 테이블 삭제
    clear_table = f"""
        DROP TABLE IF EXISTS '{resultTable}';
        DROP TABLE IF EXISTS '{cReTblName}';
        DROP TABLE IF EXISTS '{fReTblName}';
    """
    sql += clear_table

    # 임시 테이블 부분
    # 입시 테이블 생성
    create_temp_table = f"""
        CREATE TEMP TABLE '{tempResult}' as 
            SELECT 
                A."{'", A."'.join(invenOriHeader[:-1])}", 
                B."{depthColumn}" as depth, 
                0 as intersect_area, 
                area(A."{invenGeom}") as imm,
                CastTo{geomType}(
                    intersection( 
                        buffer(
                            A.'{invenGeom}', 
                            0
                        ), 
                        buffer(
                            B.'{floodGeom}', 
                            0 
                        ) 
                    )
                ) as '{invenGeom}'
            FROM 
                "{invenTable}" as A, 
                "{floodTable}" as B
            WHERE 
                Intersects(
                    B.'{floodGeom}', 
                    A.'{invenGeom}'
                )
                AND A.rowid in (
                    SELECT 
                        rowid 
                    FROM 
                        SpatialIndex 
                    WHERE 
                        f_table_name='{invenTable}' 
                        AND search_frame=B.'{floodGeom}'
                );
        CREATE TEMP TABLE
            '{cReTblName}' as {" UNION ALL ".join(cdmgList)};
        
        CREATE TEMP TABLE
            '{fReTblName}' as {" UNION ALL ".join(fdmgList)};
    """
    sql += create_temp_table

    update_temp_table = f"""
        UPDATE 
            '{tempResult}' 
        SET 
            intersect_area=area(geometry), 
            imm=area(geometry)/imm;
        
        INSERT OR IGNORE INTO 
            '{name_list.A_FDAMAGE}' 
        VALUES(
            '과수', 
            {", ".join(["0"]*12)}
        );
    """
    sql += update_temp_table

    # 테이블 업데이트
    update_table = f"""
        DROP TABLE IF EXISTS '{resultTable}';
        CREATE TABLE '{resultTable}' as 
            SELECT 
                cast(A.ogc_fid as Integer) as ogc_fid, cast(A.sig_cd as Text) as sig_cd, 
                cast(A.emd_cd as Text) as emd_cd, cast(A.l_admin as Text) as l_admin, 
                {", ".join(crpArList)}, cast(0 as Real) as sum_crp_ar,
                cast(CASE WHEN A.land_code='논' AND C.value>0 THEN A.intersect_area ELSE 0 END as Real) as pad_lnd_ar,
                cast(CASE WHEN A.land_code='시설' AND C.value>0 THEN A.intersect_area ELSE 0 END as Real) as gre_lnd_ar,
                cast(CASE WHEN A.land_code='인삼' AND C.value>0 THEN A.intersect_area ELSE 0 END as Real) as gin_lnd_ar,   
                cast(CASE WHEN A.land_code='비경지' AND C.value>0 THEN A.intersect_area ELSE 0 END as Real) as unf_lnd_ar,  
                cast(CASE WHEN A.land_code='밭' AND C.value>0 THEN A.intersect_area ELSE 0 END as Real) as upl_lnd_ar,
                {", ".join(prdLsList)}, cast(0 as Real) as sum_prd_ls,
                {", ".join(prfLsList)}, cast(0 as Real) as sum_prf_ls,
                cast(CASE WHEN A.land_code='논' AND C.value>0 THEN A.intersect_area*(D.unit/1000)*C.value/100 ELSE 0 END as Real) as pad_cst_ls,
                cast(CASE WHEN A.land_code='시설' AND C.value>0 THEN A.intersect_area*(D.unit/1000)*C.value/100 ELSE 0 END as Real) as gre_cst_ls,
                cast(CASE WHEN A.land_code='인삼' AND C.value>0 THEN A.intersect_area*(D.unit/1000)*C.value/100 ELSE 0 END as Real) as gin_cst_ls,  
                cast(CASE WHEN A.land_code='비경지' AND C.value>0 THEN A.intersect_area*(D.unit/1000)*C.value/100 ELSE 0 END as Real) as unf_cst_ls,      
                cast(CASE WHEN A.land_code='밭' AND C.value>0 THEN A.intersect_area*(D.unit/1000)*C.value/100 ELSE 0 END as Real) as upl_cst_ls,
                A."{invenGeom}"
            FROM '{tempResult}' as A, '{fReTblName}' as C , '{name_list.A_DUNIT}' as D
            WHERE A.land_code=C.farmland AND A.depth=C.depth;

        UPDATE '{resultTable}' SET ({"_crp_ar, ".join(dicKeys)}_crp_ar)=({", ".join(updtList)});
        UPDATE '{resultTable}' SET (sum_crp_ar, sum_prd_ls, sum_prf_ls) = (
            ({"_crp_ar+".join(dicKeys)}_crp_ar),
            ({"_prd_ls+".join(dicKeys)}_prd_ls),
            ({"_prf_ls+".join(dicKeys)}_prf_ls)
        );
    """
    sql += update_table
    return sql
