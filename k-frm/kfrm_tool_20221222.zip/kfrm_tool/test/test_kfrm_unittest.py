import unittest

from ..include.levelpool.level_pool import MakeFloodMap


class LevelPoolTest(unittest.TestCase):
    def setUp(self):
        self.levelPool = MakeFloodMap()

    def tearDown(self):
        """Runs after each test."""
        self.levelPool = None

    def test_calcExtent(self):
        test = [
            [120, 136, 10, 'min', 130],
            [110, 115, 30, 'min', 110],
            [210, 211, 30, 'max', 180],
            [110, 99, 30, 'max', 240]
        ]
        
        for t in test:
            with self.subTest("결과가 일치하지 않음  : " + str(t)):
                rst = self.levelPool.getCalcExtent(t[0], t[1], t[2], t[3])
                self.assertEqual(rst, t[4])

# if __name__ == "__main__":
#     print("unittest open")
suite = unittest.makeSuite(LevelPoolTest)
runner = unittest.TextTestRunner(verbosity=2)
runner.run(suite)