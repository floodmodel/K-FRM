# -*- coding: utf-8 -*-
import os
import sqlite3
from shutil import copyfile

from ...include.setting.path_list import DefaultPath

    
class TestSQLiteConnection:
    def __init__(self):
        self.path = DefaultPath()
        
        global DB_PATH, EMPTY_DB, DB_DLL_PATH
        DB_PATH = os.path.join( os.path.dirname( self.path.getSqliteDBPath() ), "../../../test/testSQL/test_SQLite.sqlite")
        EMPTY_DB = self.path.getEmptySqliteDBPath()
        copyfile(EMPTY_DB, DB_PATH)
        
        self.connectionDB()
                
    def connectionDB(self):
        global _connection, _cursor
        _connection = sqlite3.connect(DB_PATH, check_same_thread=False)
        _connection.enable_load_extension(True)
        _connection.load_extension('mod_spatialite')
        _cursor = _connection.cursor()
        self.baseCreateTable()        
 
        return _connection, _cursor
        
    def closeDB(self):
        _connection.close()    
        
    def clearDB(self): #인벤토리 구축하면서 사용했던 테이블 내용 지우기.
        sql = """
            PRAGMA writable_schema = 1;
            DELETE FROM sqlite_master WHERE (
                                name like "%"||(select table_name from flood_table_list)||"%" or
                                name like "%vehicle%" or name like "%popu%" or name like "%agricul%" or 
                                name like "%build%" or name like "%flood%"
                                or name="extent_grid") COLLATE NOCASE;
            DELETE FROM geometry_columns;
            DELETE FROM geometry_columns_auth;
            DELETE FROM geometry_columns_statistics;
            DELETE FROM geometry_columns_field_infos;
            DELETE FROM spatialite_history;
            DELETE FROM sqlite_sequence WHERE name!="spatialite_history";
            DELETE FROM geometry_columns_time;
            PRAGMA writable_schema = 0;
        """        
        self.excScript(sql)
        self.excNone("Vacuum;") #sql문에 한꺼번에 넣어 실행하면 오류남.
            
    def baseCreateTable(self):
        sqlFile = os.path.join( os.path.dirname( self.path.getSpatialSqlPath() ), "../../../test/testSQL/test_sqlite_insert.sql" ) 
        with open(sqlFile) as f:
            sql = f.read()
            self.excScript(sql)  

    def commit(self):
        _connection.commit()
    
    def exeDecorator(func):
        def decorated(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except sqlite3.Error as e:
                _connection.rollback()
                raise sqlite3.Error(e)
        return decorated

    @exeDecorator
    def excValue(self, query, type=True): # retrun 값 있음 : select
        if type:
            _cursor.execute(query)
            return _cursor.fetchall()
        else:
            return _cursor.execute(query)
            
        
    @exeDecorator
    def excNone(self, query): # return 값 없음 : update, insert, delete...
        _cursor.execute(query)
        self.commit()
    
    @exeDecorator
    def excMany(self, query, content): # insert시 한번에 값 여러개 넣기 ([1], [1]) <-이런 형태로 전달 해야 함.
        _cursor.execute("BEGIN TRANSACTION;")
        _cursor.executemany(query, tuple(content))
        _cursor.execute("END TRANSACTION;")
        self.commit()
    
    @exeDecorator
    def excQueryMany(self, query): #여러개의 쿼리를 날릴때 한꺼번에 쿼리를 날리고 후에 Commit. 
        for q in query:
            _cursor.execute(q)
        
        self.commit()
    
    @exeDecorator
    def excScript(self, query): #여려개의 쿼리를 한번에 날릴 때. 하나의 쿼리가 끝나면 ;으로 표시. 위 excQueryMany 대용.
        _cursor.executescript(query)
        self.commit()

