
create table if not exists building_costs (
	occupancy char(30),    
	description char(15),
    costs int,
    primary key ("occupancy", "description")
);

create table if not exists building_csvr (
    occupancy char(30),
    csvr real,
    primary key ("occupancy")
);

create table if not exists building_entrance (
    occupancy char(30),
    height real,
    primary key ("occupancy")
);

create table if not exists building_depreciation (
	occupancy char(30),    
	description char(15),
    persisting_period real,
    primary key ("occupancy", "description")
);

create table if not exists vehicle_costs (
    type char(6),
    costs integer,
	primary key ("type")
);

create table if not exists vehicle_salvage_rate_new (
    type character(6),
    rate real,
	primary key ("type")
);

create table if not exists population_unit_cost (
	year int,
	life_loss int,
	victim_loss int,
	primary key ("year")
);

create table if not exists agriculture_unit_price (
	farmland char(5) NOT NULL,
	crops char(9) not null,
	input_prd_cst real, 
	expct_netpr real
);

create table if not exists agriculture_unit_cost (
	unit real
);

create table if not exists building_structure_damage_rate (
	occupancy char(30), 
	description char(15),
	"0" real,	"1" real,    "2" real,    "3" real,    "4" real,
    "5" real,    "6" real,    "7" real,    "8" real,
    "9" real,    "10" real,    "11" real,
	primary key ("occupancy", "description")
);

create table if not exists building_inner_damage_rate (
	occupancy char(30), 
	"0" real,	"1" real,    "2" real,    "3" real,    "4" real,
    "5" real,    "6" real,    "7" real,    "8" real,
    "9" real,    "10" real,    "11" real,
	primary key ("occupancy")
);

create table if not exists vehicle_dmg_func (
	"type" text, 
	"0" real,	"1" real,    "2" real,    "3" real,    "4" real,
    "5" real,    "6" real,    "7" real,    "8" real,
    "9" real,    "10" real,    "11" real,
    primary key ("type")
);

create table if not exists population_life_loss (
	hierarchy text,
	"0" real,	"1" real,    "2" real,    "3" real,    "4" real,
    "5" real,    "6" real,    "7" real,    "8" real,
    "9" real,    "10" real,    "11" real,
	primary key ("hierarchy")
);

create table if not exists population_victim_loss (
	hierarchy text,
	"0" real,	"1" real,    "2" real,    "3" real,    "4" real,
    "5" real,    "6" real,    "7" real,    "8" real,
    "9" real,    "10" real,    "11" real,
	primary key ("hierarchy")
);

create table if not exists agriculture_crop_dmg_func (
	farmland character(5) NOT NULL,
	crops character(9) NOT null,
	"0" real,	"1" real,    "2" real,    "3" real,    "4" real,
    "5" real,    "6" real,    "7" real,    "8" real,
    "9" real,    "10" real,    "11" real,
	primary key (farmland, crops)
);

create table if not exists agriculture_frm_dmg_func (
	farmland character(5) NOT NULL,
	"0" real,	"1" real,    "2" real,    "3" real,    "4" real,
    "5" real,    "6" real,    "7" real,    "8" real,
    "9" real,    "10" real,    "11" real,
	primary key (farmland)
);


create table if not exists flood_table_list (
	path text, --파일 경로
	frequency int, --홍수 빈도
	comment text,
	table_name text, --테이블 명
	flood_column text, --침수 필드 명
	area text, --침수 구역도 해당 지역
	sig_cd text, --시군구 코드
	area_count text --침수 구역도 순서?
);

create table if not exists flood_sum_result(
	table_name text,
	type text, 
	building_res real,
	building_non_res real,
	vehicle real, 
	life real, 
	victim real, 
	crop real, 
	farmland real, 
	sum real
);

create table if not exists reclass_field_table(
	ogc_fid int not null,
	code text not null,
	min real not null, 
	max real not null,
	primary key (ogc_fid, code)
);


insert into building_costs values('단독주택', '조적조', 1200);
insert into building_csvr values('단독주택', 50);
insert into building_entrance values('단독주택', 1);
insert into building_depreciation values('단독주택', '조적조', 45);

insert into vehicle_costs values('PAS1', 11500);
insert into vehicle_costs values('PAS2', 12000);
insert into vehicle_costs values('PAS5', 25000);
insert into vehicle_costs values('PAS6', 12300);
insert into vehicle_costs values('VAN2', 10000);
insert into vehicle_costs values('VAN3', 28000);
insert into vehicle_salvage_rate_new values('PAS1', 40);
insert into vehicle_salvage_rate_new values('PAS2', 50);
insert into vehicle_salvage_rate_new values('PAS5', 10);
insert into vehicle_salvage_rate_new values('PAS6', 20);
insert into vehicle_salvage_rate_new values('VAN2', 30);
insert into vehicle_salvage_rate_new values('VAN3', 80);

insert into population_unit_cost values(2018, 450000, 1000);

insert into agriculture_unit_price values('논', '논벼', 346300, 264961);
insert into agriculture_unit_price values('밭', '참깨', 698606, 79520);
insert into agriculture_unit_price values('밭', '수박', 1043602, 448813);
insert into agriculture_unit_cost values(900);

insert into building_structure_damage_rate values('단독주택', '조적조', 0, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 55);
insert into building_inner_damage_rate values('단독주택', 0, 10, 20, 40, 60, 70, 80, 90, 99, 99, 99, 99);
insert into vehicle_dmg_func values('type 1', 0, 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100);
insert into vehicle_dmg_func values('type 2', 0, 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100);
insert into vehicle_dmg_func values('type 3', 0, 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100);
insert into population_life_loss values('General Population', 0, 0.2, 0.2, 0.2, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1);
insert into population_life_loss values('Vulnerable Population', 0, 0.2, 0.2, 0.2, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1);
insert into population_victim_loss values('All Population', 0, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2);
insert into agriculture_crop_dmg_func values('논', '논벼', 0, 0, 15, 15, 25, 25, 25, 25, 25, 25, 25, 25);
insert into agriculture_crop_dmg_func values('밭', '수박', 87.2, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100);
insert into agriculture_crop_dmg_func values('밭', '참깨', 29.7, 31.3, 50, 68.8, 68.8, 68.8, 68.8, 68.8, 68.8, 68.8, 68.8, 68.8);
insert into agriculture_frm_dmg_func values('논', 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 100, 100);
insert into agriculture_frm_dmg_func values('밭', 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 100, 100);

insert into flood_table_list values('', 0, 'test', 'flood', 'depth', '경기도 양주시', '41630', '_merge0');


create table flood(
	depth int
);

create table flood_c (
	depth float
);

select AddGeometryColumn('flood', 'geometry', 5179, 'POLYGON', 'XY');
select AddGeometryColumn('flood_c', 'geometry', 5179, 'POLYGON', 'XY');

insert into flood values(6, GeomFromText('POLYGON ((0 0, 0 30, 30 30, 30 0, 0 0))', 5179));
insert into flood_c values(2, GeomFromText('POLYGON ((0 0, 0 30, 30 30, 30 0, 0 0))', 5179));

create table agriculture (
	ogc_fid integer, 
	id varchar, 
	land_code varchar,
	agr_area float, 
	sig_cd varchar,
	emd_cd varchar,
	l_admin varchar,
	pad_a float,
	fru_a FLOAT, 
	gre_a FLOAT,
	gin_a FLOAT, 
	unf_a FLOAT, 
	upl_ses_a FLOAT, 
	upl_wam_a FLOAT, 
	upl_rad_a FLOAT, 
	upl_cab_a FLOAT, 
	upl_cor_a FLOAT, 
	upl_soy_a FLOAT, 
	upl_swp_a FLOAT 
);

select AddGeometryColumn('agriculture', 'geometry', 5179, 'MULTIPOLYGON', 'XY');
insert into agriculture values(0, 'X0939186Y1997138', '논', 25, '41630', '330', '경기도 양주시 광적면 우고리', 
	25, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 
	GeomFromText('MULTIPOLYGON(((-2 15, 3 15, 3 20, -2 20, -2 15)))', 5179) );
insert into agriculture values(1, 'X0939202Y1997643', '밭', 25, '41800', '330', '경기도 양주시 광적면 우고리', 
	0.0, 0.0, 0.0, 0.0, 0.0, 15, 10, 0, 0, 0, 0, 0, 
	GeomFromText('MULTIPOLYGON(((-2 0, 3 0, 3 5, -2 5, -2 0)))', 5179) );

create table population(
	ogc_fid INTEGER,
	base_year VARCHAR, 
	sig_cd VARCHAR, 
	emd_cd VARCHAR, 
	l_admin VARCHAR, 
	tot_reg_cd VARCHAR,
	tot_pop_n FLOAT,
	tot_vul_n FLOAT, 
	tot_gen_n FLOAT
);

select AddGeometryColumn('population', 'geometry', 5179, 'MULTIPOLYGON', 'XY');
insert into population values(0, '2018', '41630', '330', '경기도 양주시 광적면', '1109074010007', 
	600, 170, 430, GeomFromText('MULTIPOLYGON(((-2 5, 3 5, 3 10, -2 10, -2 5)))', 5179) );
--MULTIPOLYGON(((0 5, 5 5, 5 10, 0 10, 0 5)))

create table vehicle(
	ogc_fid INTEGER, 
	base_year VARCHAR,
	sig_cd VARCHAR,
	emd_cd VARCHAR,
	l_admin VARCHAR,
	tot_reg_cd VARCHAR, 
	pas1_n FLOAT,
	pas2_n FLOAT,
	pas3_n FLOAT,
	pas4_n FLOAT,
	pas5_n FLOAT,
	pas6_n FLOAT,
	pas7_n FLOAT,
	pas8_n FLOAT,
	pas9_n FLOAT,
	van1_n FLOAT,
	van2_n FLOAT,
	van3_n FLOAT,
	tru1_n FLOAT,
	tru2_n FLOAT,
	tru3_n FLOAT,
	tru4_n FLOAT,
	tru5_n FLOAT, 
	tru6_n FLOAT,
	tru7_n FLOAT,
	tru8_n FLOAT, 
	tru9_n FLOAT,
	tru10_n FLOAT, 
	tru11_n FLOAT, 
	typ1_n INTEGER, 
	typ2_n INTEGER, 
	typ3_n INTEGER
);
select AddGeometryColumn('vehicle', 'geometry', 5179, 'MULTIPOLYGON', 'XY');
insert into vehicle values(0, '2018', '41630', '330', '경기도 양주시 광적면', '3108056021702', 
	15, 60, 25, 1, 1, 20, 10, 4, 3, 6, 8, 1, 2, 13, 2, 1, 4, 1, 5, 3, 2, 1, 4, 107, 63, 5, 
	GeomFromText('MULTIPOLYGON(((-2 10, 3 10, 3 15, -2 15, -2 10)))', 5179) );
--MULTIPOLYGON(((0 10, 5 10, 5 15, 0 15, 0 10)))

create table building(
	ogc_fid INTEGER, 
	l_admin VARCHAR, 
	s_bdtyp VARCHAR, 
	bdtyp VARCHAR, 
	s_bdstr VARCHAR, 
	bdstr VARCHAR, 
	bd_f_area FLOAT, 
	gro_flo_co INTEGER, 
	und_flo_cd INTEGER, 
	ra_use_year VARCHAR, 
	use_year VARCHAR, 
	sig_cd VARCHAR, 
	emd_cd VARCHAR, 
	li_cd VARCHAR, 
	mntn_yn VARCHAR, 
	lnbr_mnnm VARCHAR, 
	lnbr_slno VARCHAR, 
	buld_nm_dc VARCHAR, 
	mat_res VARCHAR 
);

select AddGeometryColumn('building', 'geometry', 5179, 'MULTIPOINT', 'XY');
insert into building values(0, '경기도 양주시 광적면', '단독주택', '단독주택', '블록구조', '조적조',
	126, 1, 0, '1994', '1994', '41630', '330', '21', '0', '0526', '0016', NULL, '', 
	GeomFromText('MULTIPOINT((13 18))', 5179) );
