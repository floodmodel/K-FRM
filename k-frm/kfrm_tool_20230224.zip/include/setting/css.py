
class WidgetCss:

    def setMainCss(self):
        css = 'font : 9pt "Arial";'      
        return css
    
    def setGroupBoxTopMargin(self, padding=15, margin=-15):
        css = "QGroupBox{padding-top:%dpx; margin-top:%dpx;}" % (padding, margin)
        return css
       
    def getBoldCss(self):
        css = "font-weight : bold;"
        return css
    
    def setTableConerBorder(self):
        css = "QTableWidget QTableCornerButton::section{border:1px outset rgb(195,195,195);}"
        return css