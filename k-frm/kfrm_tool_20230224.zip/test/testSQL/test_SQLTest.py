import os
import unittest
from io import StringIO

from .db_connection import TestSQLiteConnection
from ...include.levelpool.level_pool import MakeFloodMap
from ...include.db.dao.sqlite_query_dao import SqliteQuery


class TestKFRM(unittest.TestCase):
    @classmethod
    def setUpClass(self):
        self.levelPool = MakeFloodMap()
        self.sqlite = TestSQLiteConnection()
        self.query = SqliteQuery(self.sqlite)
        
    def setUp(self):
        pass

    def tearDown(self):
        """Runs after each test."""
    
    @classmethod
    def tearDownClass(self):
        self.sqlite.closeDB()
        self.sqlite = None
        self.levelPool = None
        self.qeury = None
        
    def test_calcExtent(self):
        test = [
            [120, 136, 10, 'min', 130],
            [110, 115, 30, 'min', 110],
            [210, 211, 30, 'max', 240],
            [110, 99, 30, 'max', 110]
        ]
        
        for t in test:
            with self.subTest("결과가 일치하지 않음  : " + str(t)):
                rst = self.levelPool.getCalcExtent(t[0], t[1], t[2], t[3])
                self.assertEqual(rst, t[4])

    def test_inventory(self):
        inven = {
            "building": {
                "func" : [self.query.createBuildingValueTable, self.query.buildingLossResult],
                "columns": "str_value, cont_value, f_dmg_str, f_dmg_cont, dmg_str, dmg_cont, dmg_sum", 
                "result": [[70560, 35280, 25, 60, 17640, 21168, 38808]] 
                }, 
            "population": {
                "func" : ['', self.query.populationLossResult],
                "columns": "gen_par, vul_par, tot_par, round(gen_loss, 2), round(vul_loss, 2), " +\
                    "round(vic_loss, 2), life_cost, vic_cost",
                "result": [[258, 102, 360, 25.8, 10.2, 72, 16200000, 72000]]
#                 "result": [430, 170, 600, 43, 17, 120, 27000000, 120000]
                },
            "vehicle": {
                "func" : [self.query.createVehicleValueTable, self.query.vehicleLossResult],
                "columns": "t1_n, t2_n, t3_n, round(t1_n_exps, 2), round(t2_n_exps, 2), round(t3_n_exps, 2), " +\
                    "t1_c_exps, t2_c_exps, t3_c_exps, t1_c_dmg, t2_c_dmg, t3_c_dmg",
                "result": [[108, 63, 21, 64.8, 37.8, 12.6, 257400, 31020, 27840, 128700, 15510, 13920]]
                },
            "agriculture": {
                "func" : [self.query.createAgricultureValueTable, self.query.agricultureLossResult],
                "columns": "sum_crp_ar, round(sum_prd_ls, 2),  round(sum_prf_ls, 2), pad_cst_ls, upl_cst_ls",
                "result": [[15.0, 1.3, 0.99, 13.5, 0.0], [15.0, 10.59, 3.19, 0.0, 13.5]]
                }
        }
        
        for k, v in inven.items():
            floodTable = "flood"
            if k=="building":
                floodTable += "_c"
                
            valueTableName = k
            if k != "population":
                valueTableName += "_eval"
                v["func"][0](k, 2018)
                
            geomInfo = self.query.getGeometryInfo(k)   
            geom, srid, type, coord = geomInfo[1], geomInfo[4], geomInfo[2], geomInfo[3]
            self.query.recoverGeometry(valueTableName, geom, srid, type, coord)  
            rstName = v["func"][1](floodTable, valueTableName)  
            
            rst = self.query.getTableContents(rstName, v["columns"])
     
            for i, r in enumerate(rst):
                for j, c in enumerate(r):
                    with self.subTest(k+" 계산 결과가 일치하지 않음 ."):
                        self.assertEqual(c, v["result"][i][j])

    def test_inventory_sum_result(self):
        self.query.insertInvenInfraSumResult()
    
stream = StringIO()

suite = unittest.makeSuite(TestKFRM)
runner = unittest.TextTestRunner(stream=stream, verbosity=2)
runner.run(suite)

stream.seek(0)
print(stream.read())
logPath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_Log.txt')
with open(logPath, 'w') as f:
    f.write(stream.read())
