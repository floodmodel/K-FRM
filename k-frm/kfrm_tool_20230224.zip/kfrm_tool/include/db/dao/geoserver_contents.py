import requests

from ...setting.name_list import BASE_GEOSERVER

class ReqGeoserver:
    def getGeoserverData(self, typeName, outputFormat, viewParams):
        data = {
            "service" : "WFS",
            "version" : "1.0.0",
            "request" : "GetFeature",
            "typeName" : "krm_geoserver:"+typeName,
            "viewparams" : viewParams,
            "outputformat" : outputFormat
        }
        req = requests.post(BASE_GEOSERVER, data=data)

        return req
    
    def getContentsToCSV(self, typeName, outputPath, viewParams=""):
        req = self.getGeoserverData(typeName, "csv", viewParams)
        text = req.text.split("\r\n")
        content = []
        for t in text:
            s = t.split(",", 1)
            if len(s)>1:
                content.append(s[1].replace('  ', ''))
    
        with open(outputPath, 'w', encoding='cp949') as f:
            f.write('\n'.join(content))
            
    def getContentsToList(self, typeName, column, viewParams=""):
        req = self.getGeoserverData(typeName, "application/json", viewParams)
        features = req.json()['features']
        
        if column:
            lst = [str(i['properties'][column]) for i in features]
        else:
            lst = features
            
        return lst
    
    def dataProcessing(self, features):
        lst = []
        for f in features:
            l = []
            prop = f['properties']
            for p in prop:
                l.append(prop[p])
            lst.append(l)
            
        return lst
